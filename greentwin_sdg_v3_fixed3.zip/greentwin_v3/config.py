"""
GreenTwin-SDG v3  ·  Configuration
=====================================
Countries replace cities. SDSN 2024 individual SDG goal
scores are entered manually below from:
  https://dashboards.sdgindex.org/profiles/<country-name>

Source: Sachs, J.D., Lafortune, G., Fuller, G. (2024).
        The SDGs and the UN Summit of the Future.
        Sustainable Development Report 2024.
        Paris: SDSN, Dublin: Dublin University Press.
        DOI: 10.25546/108572

HOW TO FILL IN SDSN_2024_GOAL_SCORES:
  1. Go to https://dashboards.sdgindex.org/profiles/<country>
  2. For each SDG listed below, read the numeric goal score
     shown on that country's profile page (0-100 scale).
  3. Replace each None with the real published score.
  4. Gap scores (100 - goal_score) are computed automatically
     in 02_load_sdsn.py — do NOT enter gap scores here.
"""

import os, sys

# ── Project paths ─────────────────────────────────────────────────────────────
BASE      = os.path.dirname(os.path.abspath(__file__))
RAW       = os.path.join(BASE, "data", "raw")
PROCESSED = os.path.join(BASE, "data", "processed")
OUTPUTS   = os.path.join(BASE, "outputs")
FIGS      = os.path.join(OUTPUTS, "figures")
MODELS    = os.path.join(OUTPUTS, "models")
RESULTS   = os.path.join(OUTPUTS, "results")

# ── Study countries ───────────────────────────────────────────────────────────
# lat/lon = capital city coordinates used for Open-Meteo CAMS API queries only.
# All outputs and labels are at the country level.
# wb_code = ISO Alpha-3 for World Bank API.
COUNTRIES = {
    "Malaysia": {
        "lat": 3.1390, "lon": 101.6869,
        "wb_code": "MYS",
    },
    "Singapore": {
        "lat": 1.3521, "lon": 103.8198,
        "wb_code": "SGP",
    },
    "Thailand": {
        "lat": 13.7563, "lon": 100.5018,
        "wb_code": "THA",
    },
    "Indonesia": {
        "lat": -6.2088, "lon": 106.8456,
        "wb_code": "IDN",
    },
    "Philippines": {
        "lat": 14.5995, "lon": 120.9842,
        "wb_code": "PHL",
    },
    "Vietnam": {
        "lat": 10.8231, "lon": 106.6297,
        "wb_code": "VNM",
    },
    "Cambodia": {
        "lat": 11.5564, "lon": 104.9282,
        "wb_code": "KHM",
    },
    "Myanmar": {
        "lat": 16.8661, "lon": 96.1951,
        "wb_code": "MMR",
    },
}

# ── SDSN 2024 Individual SDG Goal Scores (USER MUST FILL IN) ─────────────────
# Enter the GOAL SCORE (0-100) from sdgindex.org/profiles/<country>
# NOT the overall SDG Index. NOT the gap score.
# The pipeline computes: gap_score = 100 - goal_score
# Cluster gap = arithmetic mean of constituent goal gaps.
#
# Clusters used:
#   Health_Environment      → mean gap of SDG3  + SDG11
#   Clean_Energy            → gap of SDG7
#   Climate_Action          → gap of SDG13
#   Institutional_Capacity  → mean gap of SDG16 + SDG17
#
SDSN_2024_GOAL_SCORES = {
    "Malaysia": {
        "SDG3":  None,   # e.g. 77.6  from sdgindex.org/profiles/malaysia
        "SDG7":  None,   # e.g. 92.5
        "SDG11": None,   # e.g. 62.1
        "SDG13": None,   # e.g. 54.1
        "SDG16": None,   # e.g. 66.5
        "SDG17": None,   # e.g. 62.3
    },
    "Singapore": {
        "SDG3":  None,
        "SDG7":  None,
        "SDG11": None,
        "SDG13": None,
        "SDG16": None,
        "SDG17": None,
    },
    "Thailand": {
        "SDG3":  None,
        "SDG7":  None,
        "SDG11": None,
        "SDG13": None,
        "SDG16": None,
        "SDG17": None,
    },
    "Indonesia": {
        "SDG3":  None,
        "SDG7":  None,
        "SDG11": None,
        "SDG13": None,
        "SDG16": None,
        "SDG17": None,
    },
    "Philippines": {
        "SDG3":  None,
        "SDG7":  None,
        "SDG11": None,
        "SDG13": None,
        "SDG16": None,
        "SDG17": None,
    },
    "Vietnam": {
        "SDG3":  None,
        "SDG7":  None,
        "SDG11": None,
        "SDG13": None,
        "SDG16": None,
        "SDG17": None,
    },
    "Cambodia": {
        "SDG3":  None,
        "SDG7":  None,
        "SDG11": None,
        "SDG13": None,
        "SDG16": None,
        "SDG17": None,
    },
    "Myanmar": {
        "SDG3":  None,
        "SDG7":  None,
        "SDG11": None,
        "SDG13": None,
        "SDG16": None,
        "SDG17": None,
    },
}

def validate_sdsn_scores():
    """Call at pipeline start — exits with instructions if any score is None."""
    missing = []
    for country, goals in SDSN_2024_GOAL_SCORES.items():
        for sdg, val in goals.items():
            if val is None:
                missing.append(f"  {country} → {sdg}")
    if missing:
        print("\n  ERROR: SDSN 2024 goal scores not filled in config.py")
        print("  Missing entries:")
        for m in missing:
            print(m)
        print("\n  Steps to fill in:")
        print("  1. Go to https://dashboards.sdgindex.org/profiles/<country>")
        print("     e.g. /profiles/malaysia, /profiles/singapore, etc.")
        print("  2. Read the numeric goal score (0-100) for each SDG listed.")
        print("  3. Enter the value in SDSN_2024_GOAL_SCORES in config.py.")
        print("  4. Re-run the pipeline.")
        sys.exit(1)

# ── Study period ──────────────────────────────────────────────────────────────
# SDSN 2024 uses indicator data through 2022-2023.
# CAMS data available from Aug 2022.
# WB data available through 2022-2023 for most indicators.
# Study window: 2022-2023 for full label-feature alignment.
YEAR_START = 2022
YEAR_END   = 2023
YEARS      = list(range(YEAR_START, YEAR_END + 1))

# ── Open-Meteo CAMS variable mapping ─────────────────────────────────────────
OPENMETEO_VARS = {
    "pm2_5":            "pm25",
    "pm10":             "pm10",
    "nitrogen_dioxide": "no2",
    "ozone":            "o3",
    "carbon_monoxide":  "co",
}
POLLUTANTS = ["pm25", "pm10", "no2", "o3", "co"]

# ── Physical QC range limits ──────────────────────────────────────────────────
QC_LIMITS = {
    "pm25": (0, 999),
    "pm10": (0, 1500),
    "no2":  (0, 2000),
    "o3":   (0, 500),
    "co":   (0, 150_000),  # µg/m³ from CAMS
}

# ── WHO 2021 guideline values ─────────────────────────────────────────────────
WHO_PM25_GUIDELINE = 5.0    # µg/m³
WHO_NO2_GUIDELINE  = 10.0   # µg/m³

# ── World Bank WDI indicator codes ────────────────────────────────────────────
# NO fallback values. API only. Missing data reported and left as NaN.
WB_INDICATORS = {
    "EG.ELC.ACCS.ZS":    "electrification_rate",    # SDG 7.1.1
    "EG.CFT.ACCS.ZS":    "clean_cooking_access",     # SDG 7.1.2
    "SH.H2O.SAFE.ZS":    "safe_water_access",        # SDG 6.1.1
    "SP.URB.TOTL.IN.ZS": "urban_population_pct",     # SDG 11 context
    "EN.ATM.PM25.MC.M3": "pm25_national_mean",       # SDG 11.6.2
}

# ── SDG cluster definitions ───────────────────────────────────────────────────
SDG_CLUSTERS = {
    "Health_Environment":    ["SDG3", "SDG11"],
    "Clean_Energy":          ["SDG7"],
    "Climate_Action":        ["SDG13"],
    "Institutional_Capacity":["SDG16", "SDG17"],
}

SEED = 42
