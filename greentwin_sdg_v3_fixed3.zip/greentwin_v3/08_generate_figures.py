"""
GreenTwin-SDG v3  ·  Step 08 — Figure Generation
==================================================
Self-contained: generates allcity (allcountry) predictions
internally, then draws Fig 2 (SHAP beeswarm) and Fig 3
(country-level SDG gap heatmap, all 8 countries, all months).

No Fig 1 — architecture diagram is built separately.

Outputs: outputs/figures/Fig2_SHAP_Beeswarm.png
         outputs/figures/Fig3_SDG_Heatmap.png
"""

import os, sys, json, warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.colors as mcolors
from matplotlib.lines import Line2D
warnings.filterwarnings("ignore")

from config import SDG_CLUSTERS, PROCESSED, MODELS, RESULTS, FIGS, COUNTRIES

os.makedirs(FIGS, exist_ok=True)
os.makedirs(RESULTS, exist_ok=True)
plt.rcParams.update({"font.family":"DejaVu Serif",
                     "axes.spines.top":False,"axes.spines.right":False})

COUNTRY_ORDER = list(COUNTRIES.keys())
MONTHS = ["Jan","Feb","Mar","Apr","May","Jun",
          "Jul","Aug","Sep","Oct","Nov","Dec"]

def generate_allcountry_preds():
    fm_path = os.path.join(PROCESSED, "feature_matrix.csv")
    if not os.path.exists(fm_path):
        print("  ERROR: feature_matrix.csv not found.")
        sys.exit(1)
    try:
        from xgboost import XGBRegressor
    except ImportError:
        print("  ERROR: xgboost not installed.")
        sys.exit(1)

    fm = pd.read_csv(fm_path)
    print(f"  Feature matrix: {len(fm):,} rows  countries={sorted(fm['country'].unique())}")

    for cluster in SDG_CLUSTERS.keys():
        out_path   = os.path.join(RESULTS, f"allcountry_preds_{cluster}.csv")
        model_path = os.path.join(MODELS, f"model_{cluster}.json")
        meta_path  = os.path.join(MODELS, f"meta_{cluster}.json")
        if not os.path.exists(model_path):
            print(f"  SKIP {cluster} — model not found")
            continue

        model = XGBRegressor(); model.load_model(model_path)
        with open(meta_path) as f:
            meta = json.load(f)
        feature_cols = meta["feature_cols"]

        avail   = [c for c in feature_cols if c in fm.columns]
        missing = [c for c in feature_cols if c not in fm.columns]
        if missing:
            for c in missing:
                fm[c] = 0.0
            print(f"  WARN {cluster}: zero-filled missing cols {missing}")

        sub = fm[avail + ["country","year","month"] +
                 ([cluster] if cluster in fm.columns else [])].copy()
        sub = sub.dropna(subset=avail)
        sub["xgb_pred"] = model.predict(sub[avail].values).clip(0, 100)
        sub.to_csv(out_path, index=False)
        print(f"  {cluster:<28s} {len(sub):>4,} rows  countries={sorted(sub['country'].unique())}")
    print()

def best_cluster():
    mp = os.path.join(RESULTS, "performance_metrics.csv")
    if not os.path.exists(mp):
        return list(SDG_CLUSTERS.keys())[0]
    df = pd.read_csv(mp)
    xgb = df[df["model"]=="XGBoost"]
    return xgb.loc[xgb["mae"].idxmin(),"cluster"] if not xgb.empty else list(SDG_CLUSTERS.keys())[0]

def make_fig2(cluster):
    shap_path = os.path.join(RESULTS, f"shap_values_{cluster}.csv")
    imp_path  = os.path.join(RESULTS, f"shap_importance_{cluster}.csv")
    if not os.path.exists(shap_path):
        print(f"  Fig 2 SKIP — SHAP files missing for {cluster}")
        return

    shap_df = pd.read_csv(shap_path)
    imp_df  = pd.read_csv(imp_path)
    top_n   = min(11, len(imp_df))
    top_feat = imp_df.head(top_n)["feature"].tolist()

    LABELS = {
        "pm25":"PM\u2082.\u2085 Monthly Mean","pm10":"PM\u2081\u2080 Monthly Mean",
        "no2":"NO\u2082 Monthly Mean","o3":"O\u2083 Monthly Mean","co":"CO Monthly Mean",
        "log_pm25":"Log PM\u2082.\u2085","log_no2":"Log NO\u2082","hei":"Health Exposure Index (HEI)",
        "obi":"Ozone Burden Index (OBI)","cop":"CO Proxy (COP)","sas":"Seasonal Anomaly Score (SAS)",
        "dci":"Data Completeness Index (DCI)",
        "electrification_rate":"Electrification Rate","clean_cooking_access":"Clean Cooking Access",
        "safe_water_access":"Safe Water Access","urban_population_pct":"Urban Population %",
        "pm25_national_mean":"PM\u2082.\u2085 National Mean (WB)",
    }

    fig, ax = plt.subplots(figsize=(7.5,5.4))
    cmap = plt.cm.RdBu_r
    np.random.seed(42)
    for rank, feat in enumerate(reversed(top_feat)):
        sv = shap_df[feat].values if feat in shap_df.columns else np.zeros(len(shap_df))
        fv = shap_df[feat].fillna(0).values if feat in shap_df.columns else np.zeros(len(shap_df))
        fv_norm = (fv-fv.min())/(np.ptp(fv)+1e-9)
        yj = rank + np.random.uniform(-0.25,0.25,len(sv))
        ax.scatter(sv, yj, c=fv_norm, cmap=cmap, vmin=0, vmax=1, alpha=0.45, s=12, linewidths=0, zorder=3)

    ax.axvline(0, color="#444", lw=0.9, zorder=2)
    for i in range(top_n):
        if i%2==0: ax.axhspan(i-0.5,i+0.5,color="#F4F7FA",zorder=1)

    ax.set_yticks(range(top_n))
    ax.set_yticklabels([LABELS.get(f,f.replace("_"," ").title()) for f in reversed(top_feat)], fontsize=8.5)
    ax.set_xlabel("SHAP Value  (impact on SDG gap score prediction)", fontsize=9)
    ax.set_ylim(-0.7, top_n-0.3)

    ax2 = ax.twinx(); ax2.set_ylim(ax.get_ylim()); ax2.set_yticks([])
    full_total = imp_df["mean_abs_shap"].sum()
    imp_vals = [float(imp_df.loc[imp_df["feature"]==f,"mean_abs_shap"].values[0])
                if f in imp_df["feature"].values else 0.0 for f in reversed(top_feat)]
    x_off = ax.get_xlim()[1]*0.68
    for i, mv in enumerate(imp_vals):
        ax2.barh(i, mv, left=x_off, height=0.38, color="#1A3A5C", alpha=0.80, zorder=4)
        ax2.text(x_off+mv+abs(x_off)*0.02, i, f"{mv:.2f}", va="center", fontsize=6.6, color="#1A3A5C")

    sm = plt.cm.ScalarMappable(cmap=cmap, norm=mcolors.Normalize(0,1)); sm.set_array([])
    cbar = plt.colorbar(sm, ax=ax, pad=0.01, fraction=0.024, aspect=28)
    cbar.set_label("Feature value\n(low \u2192 high)", fontsize=7.8)
    cbar.set_ticks([0,0.5,1]); cbar.set_ticklabels(["Low","Mid","High"])

    top3_pct = sum(imp_vals[-3:])/full_total*100
    for y in [top_n-0.55, top_n-3.45]:
        ax.axhline(y, color="#B85C00", lw=0.75, ls="--", xmax=0.42, zorder=5)
    x_ann = ax.get_xlim()[0]*0.90
    ax.annotate("", xy=(x_ann,top_n-0.55), xytext=(x_ann,top_n-3.45),
                arrowprops=dict(arrowstyle="<->", color="#B85C00", lw=1.3))
    ax.text(x_ann*0.72, top_n-2.0, f"Top 3\n({top3_pct:.0f}% var.)",
            va="center", fontsize=7.2, color="#B85C00", fontweight="bold")

    from config import YEARS
    ax.set_title(f"SHAP Beeswarm Summary \u2014 {cluster.replace('_',' ')} Cluster\n"
                 f"(n={len(shap_df):,} country-month records, {min(YEARS)}\u2013{max(YEARS)})",
                 fontsize=9.5, fontweight="bold", pad=8)

    plt.tight_layout(pad=0.6)
    out = os.path.join(FIGS, "Fig2_SHAP_Beeswarm.png")
    fig.savefig(out, dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print(f"  Fig 2 saved -> {out}")

def make_fig3(cluster):
    pred_path = os.path.join(RESULTS, f"allcountry_preds_{cluster}.csv")
    if not os.path.exists(pred_path):
        print(f"  Fig 3 SKIP — {os.path.basename(pred_path)} not found")
        return

    preds = pd.read_csv(pred_path)
    preds["year"]  = pd.to_numeric(preds["year"], errors="coerce").fillna(2023).astype(int)
    preds["month"] = pd.to_numeric(preds["month"], errors="coerce").fillna(7).astype(int)

    plot_year = int(preds["year"].max())
    preds_yr  = preds[preds["year"]==plot_year]
    countries_avail = [c for c in COUNTRY_ORDER if c in preds_yr["country"].values]
    if not countries_avail:
        countries_avail = sorted(preds_yr["country"].unique())
    n = len(countries_avail)

    pred_mat = np.full((n,12), np.nan)
    gt_mat   = np.full((n,12), np.nan)

    for ci, country in enumerate(countries_avail):
        cd = preds_yr[preds_yr["country"]==country]
        for mi in range(1,13):
            md = cd[cd["month"]==mi]
            if not md.empty:
                pred_mat[ci, mi-1] = round(float(md["xgb_pred"].mean()),0)
        if cluster in cd.columns:
            gv = cd[cluster].dropna()
            if not gv.empty:
                gt_mat[ci, 6] = round(float(gv.mean()),0)  # SDSN annual value shown in July

    cmap = mcolors.LinearSegmentedColormap.from_list(
        "sdg", ["#FFFFFF","#FEE5D9","#FC9272","#DE2D26","#67000D"])
    vmin, vmax = 0, 85

    fig, axes = plt.subplots(1,2, figsize=(12.5, 0.65*n+2.5), gridspec_kw={"wspace":0.06})

    for ax, matrix, title in zip(axes, [pred_mat, gt_mat],
        [f"GreenTwin-SDG\n(Monthly estimates, {plot_year})",
         f"SDSN 2024\n(Annual published value, {plot_year})"]):
        ax.imshow(matrix, aspect="auto", cmap=cmap, vmin=vmin, vmax=vmax, interpolation="nearest")
        ax.set_xticks(range(12)); ax.set_xticklabels(MONTHS, fontsize=8)
        ax.set_yticks(range(n))
        ax.set_yticklabels(countries_avail if ax is axes[0] else [], fontsize=9)
        ax.set_title(title, fontsize=9.2, fontweight="bold")
        ax.set_xlabel(f"Month ({plot_year})", fontsize=8.4)
        for ci in range(n):
            for mi in range(12):
                v = matrix[ci, mi]
                if not np.isnan(v):
                    tc = "white" if v>52 else "#1a1a1a"
                    fw = "bold" if ax is axes[1] else "normal"
                    ax.text(mi, ci, f"{v:.0f}", ha="center", va="center", fontsize=7, color=tc, fontweight=fw)
                else:
                    ax.text(mi, ci, "\u2014", ha="center", va="center", fontsize=6.8, color="#BBBBBB")

    cbar_ax = fig.add_axes([0.92,0.18,0.016,0.64])
    sm = plt.cm.ScalarMappable(cmap=cmap, norm=mcolors.Normalize(vmin,vmax)); sm.set_array([])
    cb = fig.colorbar(sm, cax=cbar_ax)
    cb.set_label("SDG Gap Score\n(0=on track\n85=large gap)", fontsize=8)

    legend_els = [mpatches.Patch(facecolor="white", edgecolor="#BBBBBB",
                                 label="No SDSN data shown (—)")]
    fig.legend(handles=legend_els, loc="lower center", bbox_to_anchor=(0.46,-0.04),
              ncol=1, fontsize=8, frameon=True, edgecolor="#CCCCCC")

    fig.suptitle(f"Country-Level SDG Gap Score Heatmap ({plot_year})  |  "
                 f"GreenTwin-SDG vs. SDSN 2024\nCluster: {cluster.replace('_',' ')}",
                 fontsize=10, fontweight="bold", y=1.02)

    out = os.path.join(FIGS, "Fig3_SDG_Heatmap.png")
    fig.savefig(out, dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print(f"  Fig 3 saved -> {out}")

if __name__=="__main__":
    print("-- Step A: Generating full-dataset predictions (all countries)")
    generate_allcountry_preds()
    cl = best_cluster()
    print(f"  Best-performing cluster: {cl}")
    print("\n-- Figure 2: SHAP Beeswarm")
    make_fig2(cl)
    print("\n-- Figure 3: SDG Gap Heatmap (all countries)")
    make_fig3(cl)
    print(f"\n  Done. Figures -> {FIGS}/")
