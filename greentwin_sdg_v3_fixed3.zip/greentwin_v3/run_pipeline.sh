#!/usr/bin/env bash
# GreenTwin-SDG v3 — Full Pipeline (country-level, real data only)
set -e
START=$(date +%s)
log() { echo ""; echo "======================================================"; echo "  $1"; echo "======================================================"; }
ok()  { echo "  [OK] $1"; }

log "PRE-FLIGHT CHECK"
python -c "from config import validate_sdsn_scores; validate_sdsn_scores(); print('  All SDSN 2024 scores filled in.')"

log "STEP 01 - World Bank WDI (API only, no fallback)"
python 01_acquire_worldbank.py
ok "worldbank_wdi.csv written"

log "STEP 02 - SDSN 2024 Goal Scores (user-entered, from real source)"
python 02_load_sdsn.py
ok "sdsn_cluster_targets.csv written"

log "STEP 03 - Real Air Quality (Open-Meteo CAMS, no API key)"
python 03_fetch_airquality.py
ok "cams_combined.parquet written"

log "STEP 04 - Pre-processing (no fallback values)"
python 04_preprocess.py
ok "monthly_aq.csv + monthly_wb.csv written"

log "STEP 05 - Feature Engineering"
python 05_feature_engineering.py
ok "feature_matrix.csv written"

log "STEP 06 - XGBoost Model Training"
python 06_train_models.py
ok "Models + performance_metrics.csv written"

log "STEP 07 - SHAP Explainability"
python 07_shap_analysis.py
ok "shap_summary_table.csv written"

log "STEP 08 - Figures (Fig 2 + Fig 3)"
python 08_generate_figures.py
ok "Fig2_SHAP_Beeswarm.png + Fig3_SDG_Heatmap.png written"

END=$(date +%s)
echo ""
echo "======================================================"
echo "  Pipeline complete in $((END-START))s"
echo "======================================================"
echo ""
echo "  Data sources used (ALL REAL, NO SYNTHETIC/FALLBACK):"
echo "    Air quality : Open-Meteo CAMS API (live fetch)"
echo "    World Bank  : api.worldbank.org (live fetch, no fallback)"
echo "    SDG targets : SDSN 2024 user-entered from sdgindex.org"
echo ""
echo "  Key outputs:"
echo "    data/raw/worldbank_api_report.txt   <- WB data volume report"
echo "    data/raw/cams_api_report.txt        <- CAMS data volume report"
echo "    outputs/results/performance_metrics.csv"
echo "    outputs/results/shap_summary_table.csv"
echo "    outputs/figures/Fig2_SHAP_Beeswarm.png"
echo "    outputs/figures/Fig3_SDG_Heatmap.png"
