"""
GreenTwin-SDG v3  ·  Step 07 — SHAP Explainability
====================================================
Computes TreeSHAP values for all test-set predictions.
Verifies local accuracy axiom. Produces Table III data.

Inputs : outputs/models/model_<cluster>.json/meta_<cluster>.json
         outputs/results/test_preds_<cluster>.csv
Outputs: outputs/results/shap_values_<cluster>.csv
         outputs/results/shap_importance_<cluster>.csv
         outputs/results/shap_summary_table.csv
         outputs/results/shap_report.txt
"""

import os, sys, json, warnings
import numpy as np
import pandas as pd
import shap
from xgboost import XGBRegressor
warnings.filterwarnings("ignore")

from config import SDG_CLUSTERS, MODELS, RESULTS

def main():
    os.makedirs(RESULTS, exist_ok=True)
    summary_rows = []
    report_lines = ["GreenTwin-SDG v3 · SHAP Analysis Report", "="*55, ""]

    for cluster_name in SDG_CLUSTERS.keys():
        model_path = os.path.join(MODELS, f"model_{cluster_name}.json")
        meta_path  = os.path.join(MODELS, f"meta_{cluster_name}.json")
        pred_path  = os.path.join(RESULTS, f"test_preds_{cluster_name}.csv")

        if not all(os.path.exists(p) for p in [model_path, meta_path, pred_path]):
            print(f"  SKIP {cluster_name}: model files not found.")
            continue

        print(f"\n{'─'*55}\n  Cluster : {cluster_name}")

        model = XGBRegressor()
        model.load_model(model_path)
        with open(meta_path) as f:
            meta = json.load(f)
        feature_cols = meta["feature_cols"]

        test_df = pd.read_csv(pred_path)
        X_test  = test_df[feature_cols].values
        print(f"    Test records : {len(X_test):,}")

        explainer   = shap.TreeExplainer(model)
        shap_values = explainer.shap_values(X_test)

        baseline   = float(explainer.expected_value)
        shap_sum   = shap_values.sum(axis=1)
        residual   = np.abs((shap_sum + baseline) - test_df["xgb_pred"].values).mean()
        axiom_pass = residual < 0.01
        print(f"    SHAP baseline : {baseline:.3f}")
        print(f"    Local accuracy residual : {residual:.6f}  "
              f"{'PASS' if axiom_pass else 'FAIL'}")

        shap_df = pd.DataFrame(shap_values, columns=feature_cols)
        shap_df.insert(0, "country", test_df["country"].values)
        shap_df.insert(1, "year",    test_df["year"].values if "year" in test_df.columns else np.nan)
        shap_df.insert(2, "month",   test_df["month"].values if "month" in test_df.columns else np.nan)
        shap_df.insert(3, "y_true",  test_df[cluster_name].values)
        shap_df.insert(4, "y_pred",  test_df["xgb_pred"].values)
        shap_df.to_csv(os.path.join(RESULTS, f"shap_values_{cluster_name}.csv"), index=False)

        importance = pd.DataFrame({
            "feature": feature_cols,
            "mean_abs_shap": np.abs(shap_values).mean(axis=0),
        }).sort_values("mean_abs_shap", ascending=False).reset_index(drop=True)
        importance.to_csv(os.path.join(RESULTS, f"shap_importance_{cluster_name}.csv"), index=False)

        total_var = importance["mean_abs_shap"].sum()
        top3      = importance.head(3)
        top3_pct  = top3["mean_abs_shap"].sum() / total_var * 100

        print(f"    Top-3 features:")
        for _, row in top3.iterrows():
            pct = row["mean_abs_shap"]/total_var*100
            print(f"      {row['feature']:<32s}  |SHAP|={row['mean_abs_shap']:.4f}  ({pct:.1f}%)")
        print(f"    Cumulative variance (top-3, over ALL features): {top3_pct:.1f}%")

        summary_rows.append({
            "SDG Cluster": cluster_name,
            "Top Feature 1": top3.iloc[0]["feature"], "|SHAP| 1": round(top3.iloc[0]["mean_abs_shap"],4),
            "Top Feature 2": top3.iloc[1]["feature"], "|SHAP| 2": round(top3.iloc[1]["mean_abs_shap"],4),
            "Top Feature 3": top3.iloc[2]["feature"], "|SHAP| 3": round(top3.iloc[2]["mean_abs_shap"],4),
            "Cumulative Variance (%)": round(top3_pct,1),
            "SHAP Axiom Pass": axiom_pass,
        })

        report_lines += [
            f"Cluster: {cluster_name}",
            f"  Local accuracy residual : {residual:.6f}  [{'PASS' if axiom_pass else 'FAIL'}]",
            f"  Top-3 cumulative var.   : {top3_pct:.1f}%",
            "",
        ]

    if not summary_rows:
        print("\n  ERROR: No SHAP results produced.")
        sys.exit(1)

    summary_df = pd.DataFrame(summary_rows)
    summary_df.to_csv(os.path.join(RESULTS,"shap_summary_table.csv"), index=False)

    print(f"\n{'='*55}\n  SHAP SUMMARY (Table III)\n{'='*55}")
    print(summary_df[["SDG Cluster","Top Feature 1","Top Feature 2",
                       "Top Feature 3","Cumulative Variance (%)"]].to_string(index=False))

    with open(os.path.join(RESULTS,"shap_report.txt"), "w") as f:
        f.write("\n".join(report_lines))

if __name__ == "__main__":
    main()
