"""
GreenTwin-SDG v3  ·  Step 04 — Pre-processing
================================================
Aggregates CAMS hourly data to country-month means,
log-transforms pollutants, interpolates World Bank annual
data to monthly resolution. No fallback or synthetic values
are introduced; any genuine NaN gaps are reported and left
as NaN for transparency (handled by feature engineering's
explicit interpolation/median imputation in Step 05).

Inputs : data/raw/cams_combined.parquet
         data/raw/worldbank_wdi.csv
Output : data/processed/monthly_aq.csv
         data/processed/monthly_wb.csv
         data/processed/preprocessing_report.txt
"""

import os, sys, calendar, warnings
import numpy as np
import pandas as pd
warnings.filterwarnings("ignore")

from config import COUNTRIES, POLLUTANTS, QC_LIMITS, YEARS, RAW, PROCESSED

def compute_dci(df: pd.DataFrame) -> pd.DataFrame:
    cnt = df.groupby(["country","year","month"])["pm25"].count().reset_index()
    cnt.columns = ["country","year","month","valid_hours"]
    def max_h(row):
        return calendar.monthrange(int(row["year"]), int(row["month"]))[1] * 24
    cnt["max_hours"] = cnt.apply(max_h, axis=1)
    cnt["dci"] = (cnt["valid_hours"] / cnt["max_hours"]).clip(0, 1)
    return cnt[["country","year","month","dci"]]

def monthly_agg(df: pd.DataFrame) -> pd.DataFrame:
    return df.groupby(["country","year","month"])[POLLUTANTS].mean().reset_index()

def log_transform(df: pd.DataFrame) -> pd.DataFrame:
    for p in POLLUTANTS:
        if p in df.columns:
            df[f"log_{p}"] = np.log1p(df[p].clip(lower=0))
    return df

def interpolate_wb_monthly(wb: pd.DataFrame) -> pd.DataFrame:
    """
    Expand annual WB values to monthly resolution. Genuine API gaps
    (no fallback) are interpolated WITHIN the available real data
    points only; if a country has zero real values for an indicator
    across all years, the column remains NaN and is reported.
    """
    wb_cols = [c for c in wb.columns if c not in ("country","wb_code","year")]
    rows = []
    for country in wb["country"].unique():
        sub = wb[wb["country"] == country].sort_values("year")
        for year in YEARS:
            yr_row = sub[sub["year"] == year]
            for month in range(1, 13):
                r = {"country": country, "year": year, "month": month}
                for col in wb_cols:
                    r[col] = (float(yr_row[col].values[0])
                              if not yr_row.empty and not pd.isna(yr_row[col].values[0])
                              else np.nan)
                rows.append(r)
    monthly = pd.DataFrame(rows).sort_values(["country","year","month"])

    # Interpolate ONLY between real observed values (no extrapolation
    # beyond the real data's range, no fabricated fallback)
    for col in wb_cols:
        monthly[col] = monthly.groupby("country")[col].transform(
            lambda s: s.interpolate("linear", limit_area="inside"))
    return monthly

def main():
    os.makedirs(PROCESSED, exist_ok=True)

    # ── Load CAMS data ─────────────────────────────────────────────────────────
    comb_path = os.path.join(RAW, "cams_combined.parquet")
    if not os.path.exists(comb_path):
        print(f"  ERROR: {comb_path} not found. Run step 03 first.")
        sys.exit(1)

    print("  Loading cams_combined.parquet ...")
    aq = pd.read_parquet(comb_path)
    aq["year"]  = pd.to_numeric(aq["year"],  errors="coerce").astype(int)
    aq["month"] = pd.to_numeric(aq["month"], errors="coerce").astype(int)
    aq = aq[aq["year"].isin(YEARS)]
    print(f"  Raw hourly rows : {len(aq):,}  |  countries : {sorted(aq['country'].unique())}")

    # ── QC ─────────────────────────────────────────────────────────────────────
    print("\n── Step 1: QC filtering")
    for poll, (lo, hi) in QC_LIMITS.items():
        if poll in aq.columns:
            bad = (aq[poll] < lo) | (aq[poll] > hi)
            n_bad = int(bad.sum())
            aq.loc[bad, poll] = np.nan
            if n_bad:
                print(f"  {poll:6s}  flagged {n_bad:,} outliers")

    # ── DCI ────────────────────────────────────────────────────────────────────
    print("\n── Step 2: Data Completeness Index")
    dci_df = compute_dci(aq)
    print(f"  DCI range: {dci_df['dci'].min():.2f} – {dci_df['dci'].max():.2f}  "
          f"|  mean: {dci_df['dci'].mean():.3f}")

    # ── Monthly aggregation ───────────────────────────────────────────────────
    print("\n── Step 3: Monthly aggregation")
    monthly_aq = monthly_agg(aq).merge(dci_df, on=["country","year","month"], how="left")
    print(f"  Monthly AQ rows (before empty-month removal): {len(monthly_aq):,}")

    # ── CRITICAL: Remove months with ZERO real CAMS data ─────────────────────
    # CAMS reanalysis at this Open-Meteo endpoint is not available before
    # approximately August 2022. Months with dci == 0 have NO real hourly
    # readings at all. Imputing these with a median would fabricate an
    # entire feature vector that was never measured -- this is synthetic
    # data and is explicitly excluded here rather than filled in.
    empty_months = monthly_aq[monthly_aq["dci"].fillna(0) == 0]
    if len(empty_months) > 0:
        print(f"\n  REMOVING {len(empty_months)} country-month rows with ZERO "
              f"real CAMS hours (no synthetic substitution):")
        summary = empty_months.groupby("country").apply(
            lambda g: sorted(zip(g["year"], g["month"]))).to_dict()
        for country, periods in summary.items():
            period_str = ", ".join(f"{y}-{m:02d}" for y, m in periods)
            print(f"    {country:<15s}  {len(periods)} months removed: {period_str}")
        monthly_aq = monthly_aq[monthly_aq["dci"].fillna(0) > 0].reset_index(drop=True)

    print(f"\n  Monthly AQ rows (after empty-month removal): {len(monthly_aq):,}")

    # ── Log transform ─────────────────────────────────────────────────────────
    print("\n── Step 4: Log-transformation")
    monthly_aq = log_transform(monthly_aq)

    # ── World Bank ─────────────────────────────────────────────────────────────
    wb_path = os.path.join(RAW, "worldbank_wdi.csv")
    if not os.path.exists(wb_path):
        print(f"\n  ERROR: {wb_path} not found. Run step 01 first.")
        sys.exit(1)
    wb = pd.read_csv(wb_path)

    print(f"\n── Step 5: WB annual → monthly interpolation ({len(wb):,} annual rows)")
    monthly_wb = interpolate_wb_monthly(wb)

    # Report genuine NaN coverage (no fallback was used to fill these)
    wb_cols = [c for c in wb.columns if c not in ("country","wb_code","year")]
    print(f"\n  World Bank feature coverage after interpolation (real data only):")
    for col in wb_cols:
        pct = monthly_wb[col].notna().mean() * 100
        print(f"    {col:<32s}  {pct:.0f}% non-null")
        if pct < 100:
            missing_countries = monthly_wb.loc[
                monthly_wb[col].isna(), "country"].unique()
            print(f"      ⚠ Missing for: {sorted(missing_countries)}")

    # ── Save ───────────────────────────────────────────────────────────────────
    aq_out = os.path.join(PROCESSED, "monthly_aq.csv")
    wb_out = os.path.join(PROCESSED, "monthly_wb.csv")
    monthly_aq.to_csv(aq_out, index=False)
    monthly_wb.to_csv(wb_out, index=False)

    # ── Report ─────────────────────────────────────────────────────────────────
    lines = [
        "GreenTwin-SDG v3 · Pre-processing Report",
        "Source: Open-Meteo CAMS (REAL) + World Bank API (REAL, no fallback)",
        "=" * 55,
        f"Raw hourly records  : {len(aq):,}",
        f"Monthly AQ records  : {len(monthly_aq):,}",
        f"Monthly WB records  : {len(monthly_wb):,}",
        f"Countries           : {sorted(monthly_aq['country'].unique())}",
        f"Years               : {sorted(monthly_aq['year'].unique())}",
        "",
        "Monthly pollutant statistics (post-QC, µg/m³):",
    ]
    for p in POLLUTANTS:
        if p in monthly_aq.columns:
            lines.append(f"  {p:6s}  mean={monthly_aq[p].mean():.2f}  "
                         f"std={monthly_aq[p].std():.2f}  "
                         f"missing={monthly_aq[p].isna().mean()*100:.1f}%")
    lines.append("")
    lines.append("World Bank feature coverage (real API data only, no fallback):")
    for col in wb_cols:
        pct = monthly_wb[col].notna().mean() * 100
        lines.append(f"  {col:<32s}  {pct:.0f}% non-null")

    rpt_path = os.path.join(PROCESSED, "preprocessing_report.txt")
    with open(rpt_path, "w") as f:
        f.write("\n".join(lines))

    print(f"\n{'='*55}")
    print(f"  monthly_aq.csv  ({len(monthly_aq):,} rows)")
    print(f"  monthly_wb.csv  ({len(monthly_wb):,} rows)")
    print(f"  Report → {rpt_path}")

if __name__ == "__main__":
    main()
