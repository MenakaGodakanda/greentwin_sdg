"""
GreenTwin-SDG v3  ·  Step 03 — Air Quality Data (Open-Meteo CAMS)
==================================================================
Fetches REAL hourly air quality from the Copernicus Atmosphere
Monitoring Service (CAMS) reanalysis via the Open-Meteo API.
No API key or registration required.

CAMS coordinates used = capital city lat/lon (see config.py).
All outputs labelled at the COUNTRY level.
No fallback or synthetic data.

API : https://air-quality-api.open-meteo.com/v1/air-quality
Data: CAMS reanalysis — satellite + ground-station assimilation

Output: data/raw/cams_hourly_<country>.parquet  (per country)
        data/raw/cams_combined.parquet
        data/raw/cams_api_report.txt
"""

import os, sys, time
from datetime import datetime
import requests
import pandas as pd
import numpy as np
from config import COUNTRIES, OPENMETEO_VARS, POLLUTANTS, QC_LIMITS, YEARS, RAW

BASE_URL  = "https://air-quality-api.open-meteo.com/v1/air-quality"
HOURLY_VARS = ",".join(OPENMETEO_VARS.keys())

def build_url(lat, lon, year):
    return (f"{BASE_URL}?latitude={lat}&longitude={lon}"
            f"&hourly={HOURLY_VARS}"
            f"&start_date={year}-01-01&end_date={year}-12-31"
            f"&timezone=auto")

def fetch_year(country, lat, lon, year, retries=3):
    url = build_url(lat, lon, year)
    for attempt in range(retries):
        try:
            r = requests.get(url, timeout=30)
            r.raise_for_status()
            data = r.json()
            if "hourly" not in data:
                return None
            h  = data["hourly"]
            df = pd.DataFrame({"timestamp": pd.to_datetime(h["time"])})
            for api_name, canon in OPENMETEO_VARS.items():
                raw_vals = h.get(api_name, [None]*len(df))
                df[canon] = pd.to_numeric(pd.Series(raw_vals), errors="coerce")
            df["country"] = country
            df["year"]    = df["timestamp"].dt.year
            df["month"]   = df["timestamp"].dt.month
            df["day"]     = df["timestamp"].dt.day
            df["hour"]    = df["timestamp"].dt.hour
            return df
        except requests.exceptions.ConnectionError:
            print(f"      Connection error (attempt {attempt+1}/{retries})")
            time.sleep(4)
        except requests.exceptions.Timeout:
            print(f"      Timeout (attempt {attempt+1}/{retries})")
            time.sleep(4)
        except Exception as e:
            print(f"      Error: {e}")
            return None
    return None

def apply_qc(df):
    flagged = {}
    for poll, (lo, hi) in QC_LIMITS.items():
        if poll not in df.columns:
            continue
        bad = (df[poll] < lo) | (df[poll] > hi)
        n   = int(bad.sum())
        df.loc[bad, poll] = np.nan
        flagged[poll] = n
    return df, flagged

def main():
    os.makedirs(RAW, exist_ok=True)

    # ── connectivity check ────────────────────────────────────────────────────
    print("  Checking Open-Meteo CAMS API connectivity ...")
    test_url = (f"{BASE_URL}?latitude=3.14&longitude=101.69"
                f"&hourly=pm2_5&start_date={YEARS[0]}-01-01"
                f"&end_date={YEARS[0]}-01-02&timezone=auto")
    try:
        r = requests.get(test_url, timeout=15)
        r.raise_for_status()
        _ = r.json()["hourly"]["time"]
        print("  ✓ API reachable\n")
    except Exception as e:
        print(f"\n  ERROR: Open-Meteo API unreachable: {e}")
        print("  Check your internet connection and re-run.")
        sys.exit(1)

    all_dfs      = []
    report_lines = [
        "GreenTwin-SDG v3 · Open-Meteo CAMS API Download Report",
        "=" * 60,
        f"Run time   : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"API        : {BASE_URL}",
        f"Variables  : {HOURLY_VARS}",
        f"Countries  : {list(COUNTRIES.keys())}",
        f"Years      : {YEARS}",
        f"Note: Capital city coordinates used for CAMS query.",
        f"      All results labelled at country level.",
        "",
    ]
    grand_total_rows   = 0
    grand_total_valid  = {p: 0 for p in POLLUTANTS}
    grand_total_hours  = 0

    for country, meta in COUNTRIES.items():
        lat, lon = meta["lat"], meta["lon"]
        print(f"  [{country}]  lat={lat}  lon={lon}")
        report_lines.append(f"\n{country}  (lat={lat}, lon={lon}):")

        country_dfs = []
        country_total_rows  = 0
        country_valid_pm25  = 0

        for year in YEARS:
            df = fetch_year(country, lat, lon, year)
            if df is None:
                print(f"    {year}: ✗ API returned no data — aborting")
                sys.exit(1)

            n_rows      = len(df)
            valid_pm25  = int(df["pm25"].notna().sum())
            mean_pm25   = df["pm25"].mean()
            country_total_rows += n_rows
            country_valid_pm25 += valid_pm25
            country_dfs.append(df)

            print(f"    {year}: {n_rows:,} hours  |  "
                  f"PM2.5 valid={valid_pm25:,}  mean={mean_pm25:.1f} µg/m³")
            report_lines.append(
                f"  {year}: {n_rows:,} hours  "
                f"PM2.5 valid={valid_pm25:,}  mean={mean_pm25:.1f} µg/m³")
            time.sleep(0.5)

        # QC
        country_df = pd.concat(country_dfs, ignore_index=True)
        country_df, flagged = apply_qc(country_df)

        dci = country_df["pm25"].notna().sum() / max(len(country_df), 1) * 100
        print(f"    ✓  {country_total_rows:,} total hours  |  DCI={dci:.1f}%")
        for p, n in flagged.items():
            if n > 0:
                print(f"       QC flagged {n} {p} outliers")

        report_lines.append(
            f"  Total: {country_total_rows:,} hours  DCI={dci:.1f}%  "
            f"QC flags: {flagged}")

        # Save per-country parquet
        fname = country.lower().replace(" ", "_")
        cpath = os.path.join(RAW, f"cams_hourly_{fname}.parquet")
        country_df.to_parquet(cpath, index=False)

        all_dfs.append(country_df)
        grand_total_rows  += country_total_rows
        grand_total_hours += country_total_rows
        for p in POLLUTANTS:
            if p in country_df.columns:
                grand_total_valid[p] += int(country_df[p].notna().sum())

    # ── Combine and save ──────────────────────────────────────────────────────
    combined  = pd.concat(all_dfs, ignore_index=True)
    comb_path = os.path.join(RAW, "cams_combined.parquet")
    combined.to_parquet(comb_path, index=False)

    # ── Grand summary ─────────────────────────────────────────────────────────
    print(f"\n{'='*60}")
    print(f"  CAMS API Download Summary")
    print(f"{'='*60}")
    print(f"  Countries fetched     : {combined['country'].nunique()} / {len(COUNTRIES)}")
    print(f"  Total hourly rows     : {grand_total_rows:,}")
    print(f"  Years covered         : {sorted(combined['year'].unique())}")
    print(f"\n  Per-pollutant valid readings (non-null):")
    for p in POLLUTANTS:
        if p in combined.columns:
            n_valid  = grand_total_valid[p]
            pct      = n_valid / max(grand_total_rows, 1) * 100
            mean_val = combined[p].mean()
            std_val  = combined[p].std()
            unit     = "µg/m³"
            print(f"    {p:6s}  valid={n_valid:,} ({pct:.1f}%)  "
                  f"mean={mean_val:.2f}  std={std_val:.2f}  [{unit}]")

    report_lines += [
        "",
        "GRAND SUMMARY",
        f"  Total hourly rows  : {grand_total_rows:,}",
        f"  Years              : {sorted(combined['year'].unique())}",
        f"  Countries          : {sorted(combined['country'].unique())}",
        "  Valid readings per pollutant:",
    ]
    for p in POLLUTANTS:
        if p in combined.columns:
            pct = grand_total_valid[p] / max(grand_total_rows, 1) * 100
            report_lines.append(
                f"    {p:6s}  {grand_total_valid[p]:,} ({pct:.1f}%)")

    rpt_path = os.path.join(RAW, "cams_api_report.txt")
    with open(rpt_path, "w") as f:
        f.write("\n".join(report_lines))

    print(f"\n  Combined → {comb_path}")
    print(f"  Report   → {rpt_path}")

if __name__ == "__main__":
    main()
