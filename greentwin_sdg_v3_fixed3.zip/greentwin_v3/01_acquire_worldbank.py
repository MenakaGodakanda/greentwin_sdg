"""
GreenTwin-SDG v3  ·  Step 01 — World Bank WDI (API only)
=========================================================
Fetches real WDI data from the World Bank public REST API.
NO fallback values. If the API returns no data for a given
country-indicator-year, that cell is left as NaN and reported.
If the API is completely unreachable, the script exits.

API: https://api.worldbank.org/v2/  (free, no key required)

Output: data/raw/worldbank_wdi.csv
        data/raw/worldbank_api_report.txt
"""

import os, sys, time
import requests
import pandas as pd
import numpy as np
from config import COUNTRIES, WB_INDICATORS, YEARS, RAW

WB_URL = ("https://api.worldbank.org/v2/country/{code}"
          "/indicator/{ind}?format=json&date={y0}:{y1}&per_page=100")

def fetch_indicator(wb_code: str, indicator: str) -> dict | None:
    """
    Fetch one indicator for one country from the World Bank API.
    Returns {year: value} dict or None if API unreachable.
    """
    url = WB_URL.format(code=wb_code, ind=indicator,
                        y0=YEARS[0], y1=YEARS[-1])
    for attempt in range(3):
        try:
            r = requests.get(url, timeout=15)
            r.raise_for_status()
            payload = r.json()
            if len(payload) < 2 or payload[1] is None:
                return {}        # API reachable but no data for this combo
            return {
                int(entry["date"]): float(entry["value"])
                for entry in payload[1]
                if entry["value"] is not None
                and int(entry["date"]) in YEARS
            }
        except requests.exceptions.ConnectionError:
            print(f"      ✗ Connection error (attempt {attempt+1}/3)")
            time.sleep(3)
        except requests.exceptions.Timeout:
            print(f"      ✗ Timeout (attempt {attempt+1}/3)")
            time.sleep(3)
        except Exception as e:
            print(f"      ✗ {e}")
            return {}
    return None   # None = API unreachable after 3 attempts

def main():
    os.makedirs(RAW, exist_ok=True)

    # ── connectivity check ────────────────────────────────────────────────────
    print("  Checking World Bank API connectivity ...")
    test = fetch_indicator("MYS", "EG.ELC.ACCS.ZS")
    if test is None:
        print("\n  ERROR: World Bank API is unreachable.")
        print("  Check your internet connection and re-run.")
        sys.exit(1)
    print("  ✓ API reachable\n")

    rows = []
    report_lines = [
        "GreenTwin-SDG v3 · World Bank WDI API Download Report",
        "=" * 60,
        f"API endpoint : https://api.worldbank.org/v2/",
        f"No fallback  : missing data left as NaN",
        f"Countries    : {list(COUNTRIES.keys())}",
        f"Years        : {YEARS}",
        f"Indicators   : {list(WB_INDICATORS.values())}",
        "",
    ]
    total_api_calls = 0
    total_values    = 0

    for country, meta in COUNTRIES.items():
        wb_code = meta["wb_code"]
        print(f"\n  {country} ({wb_code})")
        report_lines.append(f"\n{country} ({wb_code}):")

        for ind_code, col_name in WB_INDICATORS.items():
            total_api_calls += 1
            result = fetch_indicator(wb_code, ind_code)

            if result is None:
                print(f"    ✗ API unreachable for {col_name} — aborting")
                sys.exit(1)

            n_values = len(result)
            total_values += n_values

            for year in YEARS:
                val = result.get(year, np.nan)
                rows.append({
                    "country":   country,
                    "wb_code":   wb_code,
                    "year":      year,
                    "indicator": col_name,
                    "value":     val,
                    "source":    "API" if year in result else "no_data",
                })

            years_with_data  = sorted(result.keys())
            years_missing    = [y for y in YEARS if y not in result]
            status = (f"✓ {n_values} years with data: {years_with_data}"
                      if n_values else "✗ no data returned from API")
            missing_str = f"  missing: {years_missing}" if years_missing else ""
            print(f"    {col_name:<32s}  {status}{missing_str}")
            report_lines.append(
                f"  {col_name:<32s}  {status}{missing_str}")
            time.sleep(0.3)

    # ── pivot to wide format ──────────────────────────────────────────────────
    df = pd.DataFrame(rows)
    wide = df.pivot_table(
        index=["country", "wb_code", "year"],
        columns="indicator", values="value",
        aggfunc="mean"
    ).reset_index()
    wide.columns.name = None

    # Report NaN coverage
    ind_cols = list(WB_INDICATORS.values())
    print(f"\n{'='*60}")
    print(f"  World Bank API Download Summary")
    print(f"{'='*60}")
    print(f"  Total API calls made : {total_api_calls}")
    print(f"  Total values fetched : {total_values}")
    print(f"  Countries × years    : {len(COUNTRIES)} × {len(YEARS)} = "
          f"{len(COUNTRIES)*len(YEARS)} expected rows")
    print(f"\n  Coverage per indicator (% of country-year cells with real data):")
    for col in ind_cols:
        if col in wide.columns:
            pct = wide[col].notna().mean() * 100
            n   = wide[col].notna().sum()
            print(f"    {col:<32s}  {n:>2}/{len(wide):>2} rows  ({pct:.0f}%)")

    report_lines += [
        "",
        f"SUMMARY",
        f"  Total API calls    : {total_api_calls}",
        f"  Total values       : {total_values}",
        f"  Coverage per indicator:",
    ]
    for col in ind_cols:
        if col in wide.columns:
            pct = wide[col].notna().mean() * 100
            report_lines.append(f"    {col:<32s}  {pct:.0f}%")

    # Save
    out_csv = os.path.join(RAW, "worldbank_wdi.csv")
    out_rpt = os.path.join(RAW, "worldbank_api_report.txt")
    wide.to_csv(out_csv, index=False)
    with open(out_rpt, "w") as f:
        f.write("\n".join(report_lines))

    print(f"\n  Saved → {out_csv}  {wide.shape}")
    print(f"  Report → {out_rpt}")

if __name__ == "__main__":
    main()
