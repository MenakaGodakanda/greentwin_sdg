# GreenTwin-SDG v3 — Country-Level, Real-Data-Only Pipeline

## What changed from v2

1. **Cities replaced with countries.** All 8 study units are now countries
   (Malaysia, Singapore, Thailand, Indonesia, Philippines, Vietnam, Cambodia,
   Myanmar). Coordinates used for CAMS queries are capital cities, but all
   outputs, labels, and figures are at the country level — matching the
   country-level resolution of the SDSN report and World Bank data.

2. **No fallback values anywhere.** `01_acquire_worldbank.py` makes live
   API calls only; any country-indicator-year combination the API does not
   return is left as `NaN` and reported explicitly in
   `data/raw/worldbank_api_report.txt`. There is no hardcoded substitute.

3. **SDSN 2024 individual goal scores, manually entered.** Because the
   SDSN dashboard cannot be scraped automatically in all environments, you
   must enter the real published goal scores yourself in `config.py`.
   See instructions below.

4. **Year alignment fixed.** Study period is now 2022–2023, matching the
   underlying data window of the SDSN 2024 report as closely as possible.

5. **Cluster gap calculation uses individual SDG goal scores, not the
   overall SDG Index.** This is essential since the study only covers
   6 of the 17 SDGs.

---

## Step 1 — Fill in the SDSN 2024 scores (REQUIRED before running)

1. Go to **https://dashboards.sdgindex.org/profiles/<country>**
   (e.g. `/profiles/malaysia`, `/profiles/singapore`, `/profiles/thailand`,
   `/profiles/indonesia`, `/profiles/philippines`, `/profiles/vietnam`,
   `/profiles/cambodia`, `/profiles/myanmar`)

2. On each country's profile page, locate the goal-level dashboard wheel
   or table. Record the numeric score (0–100) shown for:
   - **SDG 3** (Good Health and Well-Being)
   - **SDG 7** (Affordable and Clean Energy)
   - **SDG 11** (Sustainable Cities and Communities)
   - **SDG 13** (Climate Action)
   - **SDG 16** (Peace, Justice and Strong Institutions)
   - **SDG 17** (Partnerships for the Goals)

3. Open `config.py` and replace every `None` in
   `SDSN_2024_GOAL_SCORES` with the real score you found.

4. Double-check: these must be **goal scores**, not the overall SDG Index
   score, and not a gap score. The pipeline computes
   `gap = 100 - goal_score` automatically.

---

## Step 2 — Run the pipeline

```bash
python3 -m venv venv
source venv/bin/activate
pip install numpy pandas scikit-learn xgboost shap matplotlib requests pyarrow

bash run_pipeline.sh
```

The pipeline will refuse to run (`validate_sdsn_scores()`) if any score is
still `None`, with instructions printed to the terminal.

---

## Step 3 — Verify real data volume

After running, check:
- `data/raw/worldbank_api_report.txt` — shows exact count of real values
  fetched per country per indicator, with explicit "no_data" markers for
  any gaps. No fallback was used to fill these.
- `data/raw/cams_api_report.txt` — shows exact hourly record counts and
  valid PM2.5 percentage fetched per country per year from the live CAMS API.

---

## Data sources (all real, all cited)

| Source | What | How obtained |
|---|---|---|
| Open-Meteo CAMS API | Hourly PM2.5, PM10, NO2, O3, CO | Live API call, no key |
| World Bank WDI API | Electrification, cooking, water, urban %, PM2.5 | Live API call, no fallback |
| SDSN 2024 | Individual SDG 3/7/11/13/16/17 goal scores | Manually entered from https://dashboards.sdgindex.org |
