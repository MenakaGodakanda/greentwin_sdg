"""
GreenTwin-SDG v3  ·  Step 02 — SDSN 2024 Goal Score Loader
============================================================
Reads the individual SDG goal scores entered manually in
config.py (from sdgindex.org/profiles/<country>), computes
per-cluster gap scores, and writes the label files.

Gap score  = 100 - goal_score  (higher gap = worse performance)
Cluster gap = arithmetic mean of constituent goal gaps

Source: Sachs, J.D., Lafortune, G., Fuller, G. (2024).
        The SDGs and the UN Summit of the Future.
        Sustainable Development Report 2024.
        Paris/Dublin: SDSN. DOI:10.25546/108572

Output: data/raw/sdsn_2024_scores.csv
        data/raw/sdsn_cluster_targets.csv
"""

import os, sys
import pandas as pd
import numpy as np
from config import (COUNTRIES, SDSN_2024_GOAL_SCORES,
                    SDG_CLUSTERS, YEARS, RAW, validate_sdsn_scores)

def main():
    os.makedirs(RAW, exist_ok=True)

    # ── Validate that all scores have been entered ────────────────────────────
    validate_sdsn_scores()   # exits with instructions if any None remains

    print("  Source : SDSN 2024 (Sachs et al., 2024) — user-entered goal scores")
    print("  URL    : https://dashboards.sdgindex.org/profiles/<country>")
    print(f"  Countries : {list(COUNTRIES.keys())}")
    print()

    goal_rows    = []
    cluster_rows = []

    for country in COUNTRIES:
        scores = SDSN_2024_GOAL_SCORES[country]

        # ── Per-goal gap scores ───────────────────────────────────────────────
        goal_row = {"country": country, "source": "SDSN 2024"}
        for sdg, score in scores.items():
            gap = round(100 - float(score), 2)
            goal_row[f"{sdg}_score"] = round(float(score), 2)
            goal_row[f"{sdg}_gap"]   = gap
        goal_rows.append(goal_row)

        # ── Cluster gap scores ────────────────────────────────────────────────
        for cluster_name, sdg_list in SDG_CLUSTERS.items():
            gaps = [round(100 - float(scores[s]), 2) for s in sdg_list]
            cluster_gap = round(np.mean(gaps), 2)

            # Assign the same cluster gap to every study year
            # (SDSN 2024 publishes one score per country per reporting cycle)
            for year in YEARS:
                for month in range(1, 13):
                    cluster_rows.append({
                        "country":     country,
                        "year":        year,
                        "month":       month,
                        "cluster":     cluster_name,
                        "cluster_gap": cluster_gap,
                        "constituent_gaps": str(gaps),
                        "constituent_sdgs": str(sdg_list),
                    })

        # ── Console reporting ─────────────────────────────────────────────────
        print(f"  {country}")
        for cluster_name, sdg_list in SDG_CLUSTERS.items():
            gaps = [round(100 - float(scores[s]), 2) for s in sdg_list]
            mean_gap = round(np.mean(gaps), 2)
            detail = " + ".join(
                [f"{s}={scores[s]}(gap={round(100-float(scores[s]),1)})"
                 for s in sdg_list])
            print(f"    {cluster_name:<28s}  gap={mean_gap:5.1f}  [{detail}]")
        print()

    # ── Save goal scores table ────────────────────────────────────────────────
    goal_df = pd.DataFrame(goal_rows)
    cluster_df = pd.DataFrame(cluster_rows)

    goal_path    = os.path.join(RAW, "sdsn_2024_scores.csv")
    cluster_path = os.path.join(RAW, "sdsn_cluster_targets.csv")
    goal_df.to_csv(goal_path,    index=False)
    cluster_df.to_csv(cluster_path, index=False)

    # ── Summary ───────────────────────────────────────────────────────────────
    print(f"{'='*60}")
    print(f"  SDSN 2024 Cluster Gap Score Summary")
    print(f"{'='*60}")
    pivot = cluster_df.drop_duplicates(
        subset=["country","cluster"])[["country","cluster","cluster_gap"]]
    pivot = pivot.pivot(index="country", columns="cluster",
                        values="cluster_gap")
    print(pivot.round(1).to_string())
    print(f"\n  Records written  : {len(cluster_df):,} "
          f"({len(COUNTRIES)} countries × {len(YEARS)} years × 12 months "
          f"× {len(SDG_CLUSTERS)} clusters)")
    print(f"  Goal scores file → {goal_path}")
    print(f"  Cluster targets  → {cluster_path}")

if __name__ == "__main__":
    main()
