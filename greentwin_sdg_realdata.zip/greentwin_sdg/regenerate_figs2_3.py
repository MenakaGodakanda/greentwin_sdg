"""
GreenTwin-SDG v1  ·  Regenerate Fig 2 & Fig 3
===============================================
Fig 1 (architecture) removed per user request.
Fig 3 rebuilt from full-dataset predictions
(all 8 cities × 60 months) instead of test-set only.
"""

import os, warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.colors as mcolors
from matplotlib.lines import Line2D
warnings.filterwarnings("ignore")

from config import SDG_CLUSTERS, RESULTS, FIGS

os.makedirs(FIGS, exist_ok=True)
plt.rcParams.update({"font.family":       "DejaVu Serif",
                     "axes.spines.top":   False,
                     "axes.spines.right": False})

CITIES_ORDER = ["Kuala Lumpur","Singapore","Bangkok","Jakarta",
                "Manila","Ho Chi Minh City","Phnom Penh","Yangon"]
MONTHS       = ["Jan","Feb","Mar","Apr","May","Jun",
                "Jul","Aug","Sep","Oct","Nov","Dec"]

# ── pick the cluster whose model had the lowest test-set MAE ──
def best_cluster() -> str:
    mp = os.path.join(RESULTS, "performance_metrics.csv")
    if not os.path.exists(mp):
        return "Health_Environment"
    df  = pd.read_csv(mp)
    xgb = df[df["model"] == "XGBoost"]
    return xgb.loc[xgb["mae"].idxmin(), "cluster"] if not xgb.empty else "Health_Environment"

# ══════════════════════════════════════════════════════════════
# FIG 2 — SHAP Beeswarm  (all-city data, best cluster)
# ══════════════════════════════════════════════════════════════
def make_fig2(cluster: str):
    shap_path = os.path.join(RESULTS, f"shap_values_{cluster}.csv")
    imp_path  = os.path.join(RESULTS, f"shap_importance_{cluster}.csv")

    if not (os.path.exists(shap_path) and os.path.exists(imp_path)):
        print(f"  Fig 2 SKIP — SHAP files missing for {cluster}")
        return

    shap_df = pd.read_csv(shap_path)
    imp_df  = pd.read_csv(imp_path)

    top_n    = min(11, len(imp_df))
    top_feat = imp_df.head(top_n)["feature"].tolist()

    # Human-readable labels
    LABELS = {
        "hei": "Health Exposure Index (HEI)",
        "sas": "Seasonal Anomaly Score (SAS)",
        "log_no2": "Log NO₂ Concentration",
        "log_pm25": "Log PM₂.₅",
        "obi": "Ozone Burden Index (OBI)",
        "cop": "CO Proxy (COP)",
        "dci": "Data Completeness Index (DCI)",
        "log_pm25_roll3": "PM₂.₅ 3-month Rolling Mean",
        "log_pm25_roll6": "PM₂.₅ 6-month Rolling Mean",
        "log_no2_roll3":  "NO₂ 3-month Rolling Mean",
        "log_no2_roll6":  "NO₂ 6-month Rolling Mean",
        "hei_roll3":      "HEI 3-month Rolling Mean",
        "hei_roll6":      "HEI 6-month Rolling Mean",
        "log_pm25_lag1":  "Log PM₂.₅ Lag-1 Month",
        "log_no2_lag1":   "Log NO₂ Lag-1 Month",
        "hei_lag1":       "HEI Lag-1 Month",
        "electrification_rate":  "Electrification Rate",
        "clean_cooking_access":  "Clean Cooking Access",
        "safe_water_access":     "Safe Water Access",
        "urban_population_pct":  "Urban Population %",
        "pm25_national_mean":    "PM₂.₅ National Mean",
        "pm25": "PM₂.₅ Monthly Mean",
        "no2":  "NO₂ Monthly Mean",
        "o3":   "O₃ Monthly Mean",
        "co":   "CO Monthly Mean",
        "pm10": "PM₁₀ Monthly Mean",
    }

    fig, ax = plt.subplots(figsize=(7.5, 5.4))
    cmap    = plt.cm.RdBu_r
    np.random.seed(42)

    for rank, feat in enumerate(reversed(top_feat)):
        y_pos   = rank
        sv      = shap_df[feat].values      if feat in shap_df.columns else np.zeros(len(shap_df))
        fv      = shap_df[feat].fillna(0).values if feat in shap_df.columns else np.zeros(len(shap_df))
        fv_norm = (fv - fv.min()) / (np.ptp(fv) + 1e-9)
        yj      = y_pos + np.random.uniform(-0.25, 0.25, len(sv))
        ax.scatter(sv, yj, c=fv_norm, cmap=cmap, vmin=0, vmax=1,
                   alpha=0.45, s=12, linewidths=0, zorder=3)

    ax.axvline(0, color="#444", lw=0.9, zorder=2)
    for i in range(top_n):
        if i % 2 == 0:
            ax.axhspan(i - 0.5, i + 0.5, color="#F4F7FA", zorder=1)

    y_labels = [LABELS.get(f, f.replace("_", " ").title()) for f in reversed(top_feat)]
    ax.set_yticks(range(top_n))
    ax.set_yticklabels(y_labels, fontsize=8.5)
    ax.set_xlabel("SHAP Value  (impact on SDG gap score prediction)", fontsize=9)
    ax.set_ylim(-0.7, top_n - 0.3)
    ax.tick_params(axis="x", labelsize=8)

    # Mean |SHAP| bar strip on the right
    ax2 = ax.twinx(); ax2.set_ylim(ax.get_ylim()); ax2.set_yticks([])
    imp_vals = []
    for f in reversed(top_feat):
        row = imp_df[imp_df["feature"] == f]
        imp_vals.append(float(row["mean_abs_shap"].values[0]) if not row.empty else 0)

    total_shap = sum(imp_vals) + 1e-9
    x_offset   = ax.get_xlim()[1] * 0.68
    for i, mv in enumerate(imp_vals):
        ax2.barh(i, mv, left=x_offset, height=0.38,
                 color="#1A3A5C", alpha=0.80, zorder=4)
        ax2.text(x_offset + mv + abs(x_offset) * 0.02, i,
                 f"{mv:.2f}", va="center", fontsize=6.6, color="#1A3A5C")
    ax2.text(x_offset + max(imp_vals) * 0.5, top_n - 0.05,
             "Mean\n|SHAP|", ha="center", va="top",
             fontsize=7.2, color="#1A3A5C", fontweight="bold")

    # Colourbar
    sm   = plt.cm.ScalarMappable(cmap=cmap, norm=mcolors.Normalize(0, 1))
    sm.set_array([])
    cbar = plt.colorbar(sm, ax=ax, pad=0.01, fraction=0.024, aspect=28)
    cbar.set_label("Feature value\n(low → high)", fontsize=7.8)
    cbar.set_ticks([0, 0.5, 1])
    cbar.set_ticklabels(["Low", "Mid", "High"])
    cbar.ax.tick_params(labelsize=7.4)

    # Top-3 bracket
    top3_pct = sum(imp_vals[-3:]) / total_shap * 100
    for y in [top_n - 0.55, top_n - 3.45]:
        ax.axhline(y, color="#B85C00", lw=0.75, ls="--", xmax=0.42, zorder=5)
    x_ann = ax.get_xlim()[0] * 0.90
    ax.annotate("", xy=(x_ann, top_n - 0.55), xytext=(x_ann, top_n - 3.45),
                arrowprops=dict(arrowstyle="<->", color="#B85C00", lw=1.3))
    ax.text(x_ann * 0.72, top_n - 2.0,
            f"Top 3\n({top3_pct:.0f}% var.)",
            va="center", fontsize=7.2, color="#B85C00", fontweight="bold")

    label = cluster.replace("_", " ")
    n_rec = len(shap_df)
    ax.set_title(
        f"SHAP Beeswarm Summary — {label} Cluster\n"
        f"(n = {n_rec:,} city-month records, 2018–2022)",
        fontsize=9.5, fontweight="bold", pad=8)

    plt.tight_layout(pad=0.6)
    out = os.path.join(FIGS, "Fig2_SHAP_Beeswarm.png")
    fig.savefig(out, dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print(f"  Fig 2 saved  →  {out}")

# ══════════════════════════════════════════════════════════════
# FIG 3 — SDG Gap Heatmap (ALL 8 cities, full monthly grid)
# ══════════════════════════════════════════════════════════════
def make_fig3(cluster: str):
    # Use all-city predictions (full feature-matrix inference)
    allcity_path = os.path.join(RESULTS, f"allcity_preds_{cluster}.csv")
    if not os.path.exists(allcity_path):
        print(f"  Fig 3 SKIP — allcity_preds_{cluster}.csv not found")
        return

    preds = pd.read_csv(allcity_path)
    preds["year"]  = preds["year"].astype(int)
    preds["month"] = preds["month"].astype(int)

    # Use 2022 (most recent study year)
    plot_year = 2022
    preds_yr  = preds[preds["year"] == plot_year]

    # Build grids
    pred_mat = np.full((8, 12), np.nan)   # GreenTwin-SDG monthly
    gt_mat   = np.full((8, 12), np.nan)   # UN annual (one value, placed in July)

    for ci, city in enumerate(CITIES_ORDER):
        cd = preds_yr[preds_yr["city"] == city]
        if cd.empty:
            continue
        for mi in range(1, 13):
            md = cd[cd["month"] == mi]
            if not md.empty:
                pred_mat[ci, mi - 1] = round(float(md["xgb_pred"].mean()), 0)
        # UN SDG annual value → July column (mid-year convention)
        if cluster in cd.columns:
            gt_val = cd[cluster].dropna()
            if not gt_val.empty:
                gt_mat[ci, 6] = round(float(gt_val.mean()), 0)

    # ── Colour scale ─────────────────────────────────────────
    cmap = mcolors.LinearSegmentedColormap.from_list(
        "sdg_gap", ["#FFFFFF", "#FEE5D9", "#FC9272", "#DE2D26", "#67000D"])
    vmin, vmax = 0, 85

    fig, axes = plt.subplots(1, 2, figsize=(12.5, 5.4),
                             gridspec_kw={"wspace": 0.06})

    for ax, matrix, title in zip(
        axes,
        [pred_mat, gt_mat],
        [f"GreenTwin-SDG\n(Monthly continuous estimates, {plot_year})",
         f"UN SDG Database\n(Annual reported value, {plot_year})"]
    ):
        ax.imshow(matrix, aspect="auto", cmap=cmap,
                  vmin=vmin, vmax=vmax, interpolation="nearest")
        ax.set_xticks(range(12))
        ax.set_xticklabels(MONTHS, fontsize=8)
        ax.set_yticks(range(8))
        ax.set_yticklabels(CITIES_ORDER if ax is axes[0] else [], fontsize=9)
        ax.set_title(title, fontsize=9.2, fontweight="bold")
        ax.set_xlabel("Month (2022)", fontsize=8.4)

        for ci in range(8):
            for mi in range(12):
                v = matrix[ci, mi]
                if not np.isnan(v):
                    tc = "white" if v > 52 else "#1a1a1a"
                    fw = "bold"  if ax is axes[1] else "normal"
                    ax.text(mi, ci, f"{v:.0f}", ha="center", va="center",
                            fontsize=7, color=tc, fontweight=fw)
                else:
                    ax.text(mi, ci, "—", ha="center", va="center",
                            fontsize=6.8, color="#BBBBBB")

        # Highlight two highest-gap cities (Phnom Penh + Yangon = rows 6, 7)
        for row in [6, 7]:
            ax.add_patch(plt.Rectangle((-0.5, row - 0.5), 12, 1,
                fill=False, edgecolor="#FF8C00", lw=2.0, zorder=5))

    # Shared colourbar
    cbar_ax = fig.add_axes([0.92, 0.18, 0.016, 0.64])
    sm = plt.cm.ScalarMappable(cmap=cmap, norm=mcolors.Normalize(vmin, vmax))
    sm.set_array([])
    cb = fig.colorbar(sm, cax=cbar_ax)
    cb.set_label("SDG Gap Score\n(0 = on track\n85 = large gap)", fontsize=8)
    cb.ax.tick_params(labelsize=7.5)

    legend_els = [
        Line2D([0], [0], color="#FF8C00", lw=2,
               label="Highest-gap cities (Yangon, Phnom Penh)"),
        mpatches.Patch(facecolor="white", edgecolor="#BBBBBB",
                       label="No official UN data available (—)"),
    ]
    fig.legend(handles=legend_els, loc="lower center",
               bbox_to_anchor=(0.47, -0.04), ncol=2,
               fontsize=8, frameon=True, edgecolor="#CCCCCC")

    cluster_label = cluster.replace("_", " ")
    fig.suptitle(
        f"City-Level SDG Gap Score Heatmap (2022)  |  "
        f"GreenTwin-SDG vs. UN SDG Database\nCluster: {cluster_label}",
        fontsize=10, fontweight="bold", y=1.02)

    out = os.path.join(FIGS, "Fig3_SDG_Heatmap.png")
    fig.savefig(out, dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print(f"  Fig 3 saved  →  {out}")

# ── Main ──────────────────────────────────────────────────────
if __name__ == "__main__":
    cl = best_cluster()
    print(f"  Best-performing cluster : {cl}")
    print("\n── Figure 2: SHAP Beeswarm")
    make_fig2(cl)
    print("── Figure 3: SDG Gap Heatmap (all 8 cities)")
    make_fig3(cl)
    print(f"\n  Done. Figures → {FIGS}/")
