# GreenTwin-SDG Pipeline Guide

## Step-by-Step Instructions for Reproducing the Results

### Prerequisites
Ubuntu 22.04+ · Python 3.10+

---

### 1. First-time Environment Setup

```bash
git clone <repo>  # or unzip the project folder
cd greentwin_sdg
bash setup.sh
source venv/bin/activate
```

`setup.sh` installs all system dependencies, creates a Python virtual
environment, and creates the required directory tree.

---

### 2. Run the Full Pipeline (one command)

```bash
source venv/bin/activate
bash run_pipeline.sh
```

Or run each step individually (see below).

---

### Step-by-Step Execution

| Step | Script | Input | Output |
|------|--------|-------|--------|
| 01 | `python 01_acquire_worldbank.py` | WB API / fallback | `data/raw/worldbank_wdi.csv` |
| 02 | `python 02_acquire_sdg.py` | SDSN 2023 values | `data/raw/un_sdg_indicators.csv` |
| 03 | `python 03_generate_airquality.py` | Simulation | `data/raw/airquality_hourly.parquet` |
| 04 | `python 04_preprocess.py` | Raw CSVs | `data/processed/monthly_*.csv` |
| 05 | `python 05_feature_engineering.py` | Monthly CSVs | `data/processed/feature_matrix.csv` |
| 06 | `python 06_train_models.py` | Feature matrix | `outputs/models/`, `outputs/results/` |
| 07 | `python 07_shap_analysis.py` | Trained models | `outputs/results/shap_*.csv` |
| 08 | `python 08_generate_figures.py` | Results CSVs | `outputs/figures/*.png` |

---

### Expected Outputs

**Performance (Table II)**

| Cluster              | MAE  | RMSE  | R²    |
|----------------------|------|-------|-------|
| Health & Environment | 4.45 | 5.49  | 0.877 |
| Clean Energy         | 4.68 | 6.11  | 0.898 |
| Climate Action       | 3.82 | 4.44  | 0.648 |
| Institutional        | 4.55 | 5.42  | 0.721 |

All clusters satisfy MAE < 6 (paper threshold = 1 SDG tier).

**SHAP Top Features (Table III)**

| Cluster              | Top Feature             | Cumul. Var. |
|----------------------|-------------------------|-------------|
| Health & Environment | clean_cooking_access    | 77.5%       |
| Clean Energy         | electrification_rate    | 92.6%       |
| Climate Action       | clean_cooking_access    | 80.8%       |
| Institutional        | co (combustion proxy)   | 70.3%       |

---

### Troubleshooting

- **API timeout (Step 01/02)**: Both scripts auto-fallback to published values.
- **Memory error (Step 03)**: Reduce `YEARS` in `config.py` to 2018–2020.
- **XGBoost version**: Tested on 2.0.3; use `pip install xgboost==2.0.3`.
