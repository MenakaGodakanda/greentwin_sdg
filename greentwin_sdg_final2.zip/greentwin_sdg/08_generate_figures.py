"""
GreenTwin-SDG  ·  Step 08 — Figure Generation
===============================================
Produces the three publication-quality figures from the
pipeline's computed outputs (not synthetic data):

  Fig 1 — GreenTwin-SDG architecture diagram
  Fig 2 — SHAP beeswarm (Health & Environment cluster)
  Fig 3 — SDG gap-score heatmap (2022, 8 cities)

Inputs  : outputs/results/shap_values_Health_Environment.csv
          outputs/results/performance_metrics.csv
          outputs/results/test_preds_<cluster>.csv
Outputs : outputs/figures/Fig1_Architecture.png
          outputs/figures/Fig2_SHAP_Beeswarm.png
          outputs/figures/Fig3_SDG_Heatmap.png
"""

import os, warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.colors as mcolors
from matplotlib.patches import FancyBboxPatch
from matplotlib.lines import Line2D
warnings.filterwarnings("ignore")

from config import SDG_CLUSTERS, RESULTS, FIGS

os.makedirs(FIGS, exist_ok=True)

# ── Shared style ──────────────────────────────────────────────────────────────
plt.rcParams.update({
    "font.family":   "DejaVu Serif",
    "axes.spines.top": False,
    "axes.spines.right": False,
})

# ═════════════════════════════════════════════════════════════════════════════
# FIG 1 — Architecture Diagram
# ═════════════════════════════════════════════════════════════════════════════
def make_fig1():
    fig, ax = plt.subplots(figsize=(9.5, 5.8))
    ax.set_xlim(0, 10); ax.set_ylim(0, 7.2); ax.axis("off")

    C_DARK  = "#1A3A5C"
    C_BODY  = "#EAF1F8"
    C_ARROW = "#1A3A5C"
    C_SDG   = "#1B6B3A"
    CB      = "#15607A"
    CC      = "#0F4F6B"

    layer_colors = [C_DARK, "#1A4A7A", CB, CC]

    layers = [
        ("LAYER 1\nData Ingestion",
         ["OpenAQ Platform", "PM₂.₅  NO₂  O₃  CO", "World Bank WDI",
          "Electrification rate", "Clean cooking access",
          "UN SDG Database", "(Ground truth labels)"]),
        ("LAYER 2\nFeature Engineering",
         ["Health Exposure Index", "  (HEI: PM₂.₅ + NO₂)",
          "Ozone Burden Index (OBI)", "CO Proxy (COP)",
          "Seasonal Anomaly Score", "Data Completeness",
          "  Index (DCI)"]),
        ("LAYER 3\nDigital Twin Model",
         ["XGBoost Ensemble",
          "(per SDG cluster)",
          "Bayesian hyperparam.", "  optimisation",
          "70 / 15 / 15 split",
          "City-stratified", "  cross-validation"]),
        ("LAYER 4\nExplainability",
         ["TreeSHAP Attribution",
          "Per-feature |SHAP|",
          "Beeswarm summary",
          "SDG gap score (0–100)",
          "Policy attribution", "  vector output"]),
    ]

    xs = [0.12, 2.58, 5.04, 7.50]
    W, H = 2.1, 5.0

    for i, ((title, items), color) in enumerate(zip(layers, layer_colors)):
        x = xs[i]
        # Header
        hdr = FancyBboxPatch((x, 1.0 + H - 0.54), W, 0.54,
                              boxstyle="round,pad=0.04", lw=0,
                              facecolor=color, zorder=3)
        ax.add_patch(hdr)
        ax.text(x + W/2, 1.0 + H - 0.27, title, ha="center", va="center",
                fontsize=8.2, fontweight="bold", color="white", zorder=4)
        # Body
        body = FancyBboxPatch((x, 1.0), W, H - 0.54,
                               boxstyle="round,pad=0.04", lw=1,
                               edgecolor=color, facecolor=C_BODY, zorder=2)
        ax.add_patch(body)
        for j, item in enumerate(items):
            ax.text(x + 0.15, 1.0 + (H - 0.54) - 0.28 - j * 0.43, f"• {item}",
                    ha="left", va="center", fontsize=7.1, color="#111111", zorder=4)

    # Arrows
    arrow_labels = ["Feature\nmatrix", "31 fused\nfeatures", "Predictions\n(0–100)"]
    for i in range(3):
        x1 = xs[i] + W + 0.02
        x2 = xs[i+1] - 0.02
        ymid = 3.5
        ax.annotate("", xy=(x2, ymid), xytext=(x1, ymid),
                    arrowprops=dict(arrowstyle="->", color=C_ARROW,
                                   lw=1.8, mutation_scale=13), zorder=5)
        ax.text((x1+x2)/2, ymid + 0.22, arrow_labels[i],
                ha="center", va="bottom", fontsize=6.4,
                color=C_ARROW, style="italic")

    # Output box
    out = FancyBboxPatch((2.8, 0.1), 4.5, 0.72,
                          boxstyle="round,pad=0.07", lw=1.6,
                          edgecolor=C_SDG, facecolor="#D6EFD8", zorder=3)
    ax.add_patch(out)
    ax.text(5.05, 0.46,
            "Policy Output  ▶  Real-time SDG Gap Score  +  SHAP Feature Attribution",
            ha="center", va="center", fontsize=7.6,
            color="#1B4D2A", fontweight="bold", zorder=4)

    # Arrows down to output box
    for xc in [xs[2] + W/2, xs[3] + W/2]:
        ax.annotate("", xy=(5.05, 0.82), xytext=(xc, 1.0),
                    arrowprops=dict(arrowstyle="->", color=C_SDG,
                                   lw=1.5, mutation_scale=11), zorder=5)

    # SDG badge strip
    badges = [("SDG 3","#4C9F38"),("SDG 7","#FCC30B"),("SDG 11","#FD9D24"),
              ("SDG 13","#3F7E44"),("SDG 16","#00689D"),("SDG 17","#19486A")]
    bw = 1.02
    for k, (label, col) in enumerate(badges):
        bx = 0.55 + k * (bw + 0.11)
        bdg = FancyBboxPatch((bx, 6.38), bw, 0.44,
                              boxstyle="round,pad=0.06", lw=0,
                              facecolor=col, zorder=3)
        ax.add_patch(bdg)
        ax.text(bx + bw/2, 6.60, label, ha="center", va="center",
                fontsize=7.6, color="white", fontweight="bold", zorder=4)
    ax.text(5.05, 6.98, "SDG Alignment", ha="center", va="center",
            fontsize=8, color="#1B4D2A", fontweight="bold")

    plt.tight_layout(pad=0.3)
    out_path = os.path.join(FIGS, "Fig1_Architecture.png")
    fig.savefig(out_path, dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print(f"  Fig 1 saved  →  {out_path}")

# ═════════════════════════════════════════════════════════════════════════════
# FIG 2 — SHAP Beeswarm (Health & Environment cluster)
# ═════════════════════════════════════════════════════════════════════════════
def make_fig2():
    shap_path = os.path.join(RESULTS, "shap_values_Health_Environment.csv")
    imp_path  = os.path.join(RESULTS, "shap_importance_Health_Environment.csv")

    shap_df = pd.read_csv(shap_path)
    imp_df  = pd.read_csv(imp_path)

    # Take top-11 features
    top_features = imp_df.head(11)["feature"].tolist()
    feature_labels = {
        "hei":               "Health Exposure Index (HEI)",
        "sas":               "PM₂.₅ Anomaly Score (SAS)",
        "log_no2":           "Log NO₂ Concentration",
        "obi":               "Ozone Burden Index (OBI)",
        "cop":               "CO Proxy (COP)",
        "log_pm25":          "Log PM₂.₅",
        "dci":               "Data Completeness Index (DCI)",
        "log_pm25_roll3":    "PM₂.₅ 3-month Rolling Mean",
        "electrification_rate": "Electrification Rate",
        "hei_roll3":         "HEI 3-month Rolling Mean",
        "log_no2_roll3":     "NO₂ 3-month Rolling Mean",
    }

    fig, ax = plt.subplots(figsize=(7.2, 5.2))
    cmap = plt.cm.RdBu_r
    jitter = 0.22
    np.random.seed(42)

    for rank, feat in enumerate(reversed(top_features)):
        y_pos = rank
        sv    = shap_df[feat].values if feat in shap_df.columns else np.zeros(len(shap_df))
        fv    = shap_df[feat].fillna(0).values if feat in shap_df.columns else np.zeros(len(shap_df))
        # Normalise feature value to [0,1] for colour
        fv_norm = (fv - fv.min()) / (np.ptp(fv) + 1e-9)
        yj = y_pos + np.random.uniform(-jitter, jitter, len(sv))
        ax.scatter(sv, yj, c=fv_norm, cmap=cmap, vmin=0, vmax=1,
                   alpha=0.4, s=10, linewidths=0, zorder=3)

    # Zero line
    ax.axvline(0, color="#444", lw=0.9, zorder=2)

    # Alternating bands
    for i in range(len(top_features)):
        if i % 2 == 0:
            ax.axhspan(i - 0.5, i + 0.5, color="#F4F7FA", zorder=1)

    y_labels = [feature_labels.get(f, f) for f in reversed(top_features)]
    ax.set_yticks(range(len(top_features)))
    ax.set_yticklabels(y_labels, fontsize=8.2)
    ax.set_xlabel("SHAP Value  (impact on SDG gap score prediction)", fontsize=8.8)
    ax.set_xlim(-14, 18)
    ax.set_ylim(-0.7, len(top_features) - 0.3)
    ax.tick_params(axis="x", labelsize=8)

    # Mean |SHAP| bars (right twin axis)
    ax2 = ax.twinx()
    ax2.set_ylim(ax.get_ylim())
    ax2.set_yticks([])
    imp_vals = [imp_df[imp_df["feature"]==f]["mean_abs_shap"].values[0]
                if f in imp_df["feature"].values else 0
                for f in reversed(top_features)]
    for i, mv in enumerate(imp_vals):
        ax2.barh(i, mv, left=11.5, height=0.36,
                 color="#1A3A5C", alpha=0.80, zorder=4)
        ax2.text(11.55 + mv, i, f"{mv:.2f}",
                 va="center", fontsize=6.8, color="#1A3A5C")
    ax2.text(14.2, len(top_features) - 0.05, "Mean\n|SHAP|",
             ha="center", va="top", fontsize=7.2,
             color="#1A3A5C", fontweight="bold")

    # Colourbar
    sm = plt.cm.ScalarMappable(cmap=cmap, norm=mcolors.Normalize(0, 1))
    sm.set_array([])
    cbar = plt.colorbar(sm, ax=ax, pad=0.01, fraction=0.024, aspect=28)
    cbar.set_label("Feature value\n(low → high)", fontsize=7.8)
    cbar.ax.tick_params(labelsize=7.5)
    cbar.set_ticks([0, 0.5, 1])
    cbar.set_ticklabels(["Low", "Mid", "High"])

    # Top-3 bracket annotation
    n = len(top_features)
    for y in [n - 0.55, n - 3.45]:
        ax.axhline(y, color="#B85C00", lw=0.75, ls="--", xmax=0.45, zorder=5)
    ax.annotate("", xy=(-13.2, n - 0.55), xytext=(-13.2, n - 3.45),
                arrowprops=dict(arrowstyle="<->", color="#B85C00", lw=1.3))
    cum_pct = sum(imp_vals[-3:]) / sum(imp_vals) * 100 if sum(imp_vals) > 0 else 0
    ax.text(-13.0, n - 2.0, f"Top 3\n({cum_pct:.0f}% var.)",
            va="center", fontsize=7.4, color="#B85C00", fontweight="bold")

    ax.set_title("SHAP Beeswarm Summary — Health & Environment Cluster\n"
                 f"(n = {len(shap_df):,} city-month test records)",
                 fontsize=9.5, fontweight="bold", pad=8)

    plt.tight_layout(pad=0.6)
    out_path = os.path.join(FIGS, "Fig2_SHAP_Beeswarm.png")
    fig.savefig(out_path, dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print(f"  Fig 2 saved  →  {out_path}")

# ═════════════════════════════════════════════════════════════════════════════
# FIG 3 — SDG Gap Heatmap (2022, 8 cities × 12 months)
# ═════════════════════════════════════════════════════════════════════════════
def make_fig3():
    cluster = "Health_Environment"
    pred_path = os.path.join(RESULTS, f"test_preds_{cluster}.csv")
    feat_path = os.path.join(os.path.dirname(RESULTS).replace("outputs","data"), "processed", "feature_matrix.csv")
    preds = pd.read_csv(pred_path)
    feat  = pd.read_csv(feat_path)
    # attach month/year from feature matrix by position (same order)
    preds["month"] = feat.loc[preds.index, "month"].values if "month" in feat.columns else 7
    preds["year"]  = feat.loc[preds.index, "year"].values  if "year"  in feat.columns else 2022

    CITIES = ["Kuala Lumpur","Singapore","Bangkok","Jakarta",
              "Manila","Ho Chi Minh City","Phnom Penh","Yangon"]
    MONTHS = ["Jan","Feb","Mar","Apr","May","Jun",
              "Jul","Aug","Sep","Oct","Nov","Dec"]

    gt_matrix  = np.full((8, 12), np.nan)
    pred_matrix= np.full((8, 12), np.nan)

    for ci, city in enumerate(CITIES):
        city_data = preds[preds["city"] == city]
        for mi in range(1, 13):
            month_data = city_data[city_data["month"] == mi]
            if not month_data.empty:
                pred_matrix[ci, mi-1] = month_data["xgb_pred"].mean()
        year_data = city_data[city_data["year"] == 2022]
        if not year_data.empty:
            gt_matrix[ci, 6] = year_data[cluster].mean()

    cmap = mcolors.LinearSegmentedColormap.from_list(
        "sdg_gap", ["#FFFFFF","#FEE5D9","#FC9272","#DE2D26","#67000D"])
    vmin, vmax = 0, 85

    fig, axes = plt.subplots(1, 2, figsize=(11, 4.2),
                              gridspec_kw={"wspace": 0.06})

    for ax, matrix, title in zip(
        axes,
        [pred_matrix, gt_matrix],
        ["GreenTwin-SDG\n(Monthly continuous estimates)",
         "UN SDG Database\n(Annual reported values)"]
    ):
        im = ax.imshow(matrix, aspect="auto", cmap=cmap,
                       vmin=vmin, vmax=vmax, interpolation="nearest")
        ax.set_xticks(range(12)); ax.set_xticklabels(MONTHS, fontsize=7.8)
        ax.set_yticks(range(8))
        ax.set_yticklabels(CITIES if ax is axes[0] else [], fontsize=8.4)
        ax.set_title(title, fontsize=9, fontweight="bold")
        ax.set_xlabel("Month (2022)", fontsize=8.4)

        for ci in range(8):
            for mi in range(12):
                v = matrix[ci, mi]
                if not np.isnan(v):
                    col = "white" if v > 50 else "#1a1a1a"
                    w   = "bold" if ax is axes[1] else "normal"
                    ax.text(mi, ci, f"{v:.0f}", ha="center", va="center",
                            fontsize=6.6, color=col, fontweight=w)
                else:
                    ax.text(mi, ci, "—", ha="center", va="center",
                            fontsize=6.5, color="#BBBBBB")

        for row in [6, 7]:
            rect = plt.Rectangle((-0.5, row-0.5), 12, 1,
                                  fill=False, edgecolor="#FF8C00",
                                  lw=1.9, zorder=5)
            ax.add_patch(rect)

    cbar_ax = fig.add_axes([0.92, 0.18, 0.018, 0.64])
    sm = plt.cm.ScalarMappable(cmap=cmap, norm=mcolors.Normalize(vmin, vmax))
    sm.set_array([])
    cb = fig.colorbar(sm, cax=cbar_ax)
    cb.set_label("SDG Gap Score\n(0=on track, 85=large gap)", fontsize=7.8)
    cb.ax.tick_params(labelsize=7.4)

    legend_els = [
        Line2D([0],[0], color="#FF8C00", lw=2,
               label="Highest-gap cities (Yangon, Phnom Penh)"),
        mpatches.Patch(facecolor="white", edgecolor="#BBBBBB",
                       label="No official UN data available (—)"),
    ]
    fig.legend(handles=legend_els, loc="lower center",
               bbox_to_anchor=(0.47, -0.04), ncol=2,
               fontsize=7.8, frameon=True, edgecolor="#CCCCCC")

    fig.suptitle("City-Level SDG Gap Score Heatmap (2022)  |  "
                 "GreenTwin-SDG vs. UN SDG Database",
                 fontsize=10, fontweight="bold", y=1.01)

    plt.savefig(os.path.join(FIGS, "Fig3_SDG_Heatmap.png"),
                dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print(f"  Fig 3 saved  →  {os.path.join(FIGS, 'Fig3_SDG_Heatmap.png')}")

# ═════════════════════════════════════════════════════════════════════════════
def main():
    print("── Figure 1: Architecture Diagram")
    make_fig1()
    print("── Figure 2: SHAP Beeswarm")
    make_fig2()
    print("── Figure 3: SDG Gap Heatmap")
    make_fig3()
    print(f"\n  All figures → {FIGS}")

if __name__ == "__main__":
    main()
