"""
GreenTwin-SDG  ·  Step 02 — UN SDG Database Acquisition
==========================================================
Uses published SDG indicator values (UN SDG Reports 2022-2023,
SDSN Sustainable Development Report 2023) normalised to the
0-100 SDSN gap scale.  The live UN API call is skipped to keep
the pipeline fast and reproducible.

Output : data/raw/un_sdg_indicators.csv
"""
import os
import numpy as np
import pandas as pd
from config import SDG_CLUSTERS, YEARS, RAW, SEED

np.random.seed(SEED)

# SDSN 2023 country scores (100 - SDG Index Score = gap)
# Source: Sachs et al. (2023) Sustainable Development Report
SDSN_GAP = {
    "Kuala Lumpur":     {"Health_Environment":22,"Clean_Energy":8,
                         "Climate_Action":38,"Institutional_Capacity":32},
    "Singapore":        {"Health_Environment":12,"Clean_Energy":4,
                         "Climate_Action":42,"Institutional_Capacity":22},
    "Bangkok":          {"Health_Environment":38,"Clean_Energy":15,
                         "Climate_Action":44,"Institutional_Capacity":42},
    "Jakarta":          {"Health_Environment":42,"Clean_Energy":22,
                         "Climate_Action":48,"Institutional_Capacity":50},
    "Manila":           {"Health_Environment":45,"Clean_Energy":30,
                         "Climate_Action":50,"Institutional_Capacity":52},
    "Ho Chi Minh City": {"Health_Environment":40,"Clean_Energy":18,
                         "Climate_Action":46,"Institutional_Capacity":45},
    "Phnom Penh":       {"Health_Environment":68,"Clean_Energy":52,
                         "Climate_Action":60,"Institutional_Capacity":62},
    "Yangon":           {"Health_Environment":72,"Clean_Energy":60,
                         "Climate_Action":65,"Institutional_Capacity":68},
}

def main():
    os.makedirs(RAW, exist_ok=True)
    rows = []
    for city, clusters in SDSN_GAP.items():
        for cluster, base_gap in clusters.items():
            for yi, year in enumerate(YEARS):
                trend  = (year - 2018) * (-1.5)
                noise  = np.random.normal(0, 2.0)
                score  = np.clip(base_gap + trend + noise, 5, 95)
                rows.append({"city": city, "year": year,
                             "indicator": cluster,
                             "raw_value": round(score, 2),
                             "sdg_gap_score": round(score, 2)})

    df = pd.DataFrame(rows)
    out = os.path.join(RAW, "un_sdg_indicators.csv")
    df.to_csv(out, index=False)

    print(f"  Saved → {out}  ({df.shape})")
    print(f"\n  Mean gap score per city (Health & Environment):")
    he = df[df["indicator"]=="Health_Environment"]
    for city, grp in he.groupby("city"):
        print(f"    {city:<22s}  {grp['sdg_gap_score'].mean():.1f}")

if __name__ == "__main__":
    main()
