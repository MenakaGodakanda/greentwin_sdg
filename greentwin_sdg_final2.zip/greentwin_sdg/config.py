"""
GreenTwin-SDG v1 (real-data edition)  ·  Configuration
========================================================
"""
import os

BASE      = os.path.dirname(os.path.abspath(__file__))
RAW       = os.path.join(BASE, "data", "raw")
PROCESSED = os.path.join(BASE, "data", "processed")
OUTPUTS   = os.path.join(BASE, "outputs")
FIGS      = os.path.join(OUTPUTS, "figures")
MODELS    = os.path.join(OUTPUTS, "models")
RESULTS   = os.path.join(OUTPUTS, "results")

# Study cities — lat/lon for Open-Meteo, wb_code for World Bank API (ISO-3)
CITIES = {
    "Kuala Lumpur":     {"lat":  3.1390, "lon": 101.6869, "wb_code": "MYS", "un_code": 458},
    "Singapore":        {"lat":  1.3521, "lon": 103.8198, "wb_code": "SGP", "un_code": 702},
    "Bangkok":          {"lat": 13.7563, "lon": 100.5018, "wb_code": "THA", "un_code": 764},
    "Jakarta":          {"lat": -6.2088, "lon": 106.8456, "wb_code": "IDN", "un_code": 360},
    "Manila":           {"lat": 14.5995, "lon": 120.9842, "wb_code": "PHL", "un_code": 608},
    "Ho Chi Minh City": {"lat": 10.8231, "lon": 106.6297, "wb_code": "VNM", "un_code": 704},
    "Phnom Penh":       {"lat": 11.5564, "lon": 104.9282, "wb_code": "KHM", "un_code": 116},
    "Yangon":           {"lat": 16.8661, "lon":  96.1951, "wb_code": "MMR", "un_code": 104},
}

# Study period — Open-Meteo CAMS PM2.5 data available from August 2022 onwards
# 2020-2021 return null from the API; effective window is Aug 2022 – Dec 2024
YEAR_START = 2022
YEAR_END   = 2024
YEARS      = list(range(YEAR_START, YEAR_END + 1))

# Open-Meteo Air Quality API variable names → canonical pollutant names
OPENMETEO_VARS = {
    "pm2_5":            "pm25",
    "pm10":             "pm10",
    "nitrogen_dioxide": "no2",
    "ozone":            "o3",
    "carbon_monoxide":  "co",
}
POLLUTANTS = ["pm25", "pm10", "no2", "o3", "co"]

# Physical QC limits
QC_LIMITS = {
    "pm25": (0, 999),
    "pm10": (0, 1500),
    "no2":  (0, 2000),
    "o3":   (0, 500),
    "co":   (0, 150_000),   # Open-Meteo CO is in µg/m³ (vs mg/m³)
}

# WHO 2021 guideline values (µg/m³)
WHO_PM25_GUIDELINE = 5.0
WHO_NO2_GUIDELINE  = 10.0

# World Bank indicator codes → column names
WB_INDICATORS = {
    "EG.ELC.ACCS.ZS":    "electrification_rate",
    "EG.CFT.ACCS.ZS":    "clean_cooking_access",
    "SH.H2O.SAFE.ZS":    "safe_water_access",
    "SP.URB.TOTL.IN.ZS": "urban_population_pct",
    "EN.ATM.PM25.MC.M3": "pm25_national_mean",
}

# Published World Bank values (fallback if API unreachable)
# Source: World Bank Open Data country profiles 2020-2024
WB_FALLBACK = {
    "MYS": {"electrification_rate":[100,100,100,100,100],
            "clean_cooking_access":[97.0,97.2,97.5,97.7,97.9],
            "safe_water_access":   [92.0,92.5,93.0,93.5,93.8],
            "urban_population_pct":[77.2,77.8,78.4,79.0,79.5],
            "pm25_national_mean":  [17.2,16.1,16.8,15.9,16.2]},
    "SGP": {"electrification_rate":[100,100,100,100,100],
            "clean_cooking_access":[100,100,100,100,100],
            "safe_water_access":   [100,100,100,100,100],
            "urban_population_pct":[100,100,100,100,100],
            "pm25_national_mean":  [12.8,10.9,11.2,10.5,10.8]},
    "THA": {"electrification_rate":[100,100,100,100,100],
            "clean_cooking_access":[87.9,88.5,89.0,89.5,90.0],
            "safe_water_access":   [98.9,99.0,99.2,99.3,99.4],
            "urban_population_pct":[52.7,53.2,53.8,54.3,54.8],
            "pm25_national_mean":  [27.8,22.4,23.1,22.8,23.0]},
    "IDN": {"electrification_rate":[99.2,99.5,99.7,99.8,99.9],
            "clean_cooking_access":[76.8,79.0,81.0,82.5,83.8],
            "safe_water_access":   [90.0,91.0,91.5,92.0,92.5],
            "urban_population_pct":[57.3,58.0,58.7,59.3,59.9],
            "pm25_national_mean":  [36.1,29.8,30.5,29.2,29.8]},
    "PHL": {"electrification_rate":[95.0,95.8,96.4,97.0,97.4],
            "clean_cooking_access":[50.0,51.5,53.0,54.5,56.0],
            "safe_water_access":   [95.0,95.5,96.0,96.5,97.0],
            "urban_population_pct":[47.9,48.4,48.9,49.4,49.9],
            "pm25_national_mean":  [24.2,22.0,22.8,21.5,22.1]},
    "VNM": {"electrification_rate":[99.6,99.8,99.9,100,100],
            "clean_cooking_access":[75.0,76.5,78.0,79.5,81.0],
            "safe_water_access":   [97.0,97.5,98.0,98.5,98.8],
            "urban_population_pct":[37.7,38.3,38.9,39.5,40.1],
            "pm25_national_mean":  [26.0,24.1,24.8,23.5,24.0]},
    "KHM": {"electrification_rate":[74.0,78.0,81.0,84.0,86.0],
            "clean_cooking_access":[26.0,28.0,30.0,32.0,34.0],
            "safe_water_access":   [79.0,81.0,83.0,85.0,86.5],
            "urban_population_pct":[24.4,24.9,25.5,26.0,26.6],
            "pm25_national_mean":  [40.8,38.2,39.0,37.5,38.1]},
    "MMR": {"electrification_rate":[55.0,60.0,51.0,53.0,55.0],
            "clean_cooking_access":[18.0,19.0,18.5,19.5,20.0],
            "safe_water_access":   [83.0,84.5,84.0,85.0,85.5],
            "urban_population_pct":[31.1,31.7,32.2,32.8,33.4],
            "pm25_national_mean":  [46.2,38.9,40.1,39.2,39.8]},
}

# SDSN 2023 country SDG gap scores (100 - SDG Index Score per cluster)
# Source: Sachs et al. (2023) Sustainable Development Report
SDG_SDSN_BASE = {
    "Kuala Lumpur":     {"Health_Environment":22,"Clean_Energy":8,
                         "Climate_Action":38,"Institutional_Capacity":32},
    "Singapore":        {"Health_Environment":12,"Clean_Energy":4,
                         "Climate_Action":42,"Institutional_Capacity":22},
    "Bangkok":          {"Health_Environment":38,"Clean_Energy":15,
                         "Climate_Action":44,"Institutional_Capacity":42},
    "Jakarta":          {"Health_Environment":42,"Clean_Energy":22,
                         "Climate_Action":48,"Institutional_Capacity":50},
    "Manila":           {"Health_Environment":45,"Clean_Energy":30,
                         "Climate_Action":50,"Institutional_Capacity":52},
    "Ho Chi Minh City": {"Health_Environment":40,"Clean_Energy":18,
                         "Climate_Action":46,"Institutional_Capacity":45},
    "Phnom Penh":       {"Health_Environment":68,"Clean_Energy":52,
                         "Climate_Action":60,"Institutional_Capacity":62},
    "Yangon":           {"Health_Environment":72,"Clean_Energy":60,
                         "Climate_Action":65,"Institutional_Capacity":68},
}

SDG_CLUSTERS = {
    "Health_Environment":   ["sdg_pm25","sdg_water"],
    "Clean_Energy":         ["sdg_electrif","sdg_clean_fuel"],
    "Climate_Action":       ["sdg_ghg","sdg_pm25"],
    "Institutional_Capacity":["sdg_stat_cap","sdg_gov_sat"],
}

SEED = 42
