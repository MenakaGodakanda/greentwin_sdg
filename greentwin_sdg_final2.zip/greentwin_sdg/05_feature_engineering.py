"""
GreenTwin-SDG  ·  Step 05 — Feature Engineering
=================================================
Constructs the full input feature matrix (31 features)
described in Section III-C of the paper.

Output : data/processed/feature_matrix.csv
"""
import os, warnings
import numpy as np
import pandas as pd
from config import CITIES, SDG_CLUSTERS, RAW, PROCESSED, WHO_PM25_GUIDELINE, WHO_NO2_GUIDELINE
warnings.filterwarnings("ignore")

POLLUTANTS = ["pm25","pm10","no2","o3","co"]

# ── composite feature builders ─────────────────────────────────────────────────
def build_hei(df):
    return np.sqrt((df["pm25"]/WHO_PM25_GUIDELINE) * (df["no2"]/WHO_NO2_GUIDELINE)).rename("hei")

def build_obi(df): return (df["o3"]/100.0).clip(0,5).rename("obi")

def build_cop(df): return (df["co"]/4.0).rename("cop")

def build_sas(df):
    df = df.copy()
    df["sas"] = np.nan
    for city in df["city"].unique():
        m = df["city"]==city
        s = df.loc[m,"log_pm25"]
        rm = s.rolling(36,min_periods=6).mean().shift(1)
        rs = s.rolling(36,min_periods=6).std().shift(1)
        df.loc[m,"sas"] = ((s - rm) / rs.replace(0,np.nan)).values
    return df["sas"].fillna(0.0)

def add_lag_rolling(df):
    for p in ["log_pm25","log_no2","hei"]:
        for w in [3,6]:
            df[f"{p}_roll{w}"] = df.groupby("city")[p].transform(
                lambda s: s.rolling(w,min_periods=1).mean())
        df[f"{p}_lag1"] = df.groupby("city")[p].shift(1).bfill()
    return df

def main():
    os.makedirs(PROCESSED, exist_ok=True)

    aq  = pd.read_csv(os.path.join(PROCESSED,"monthly_aq.csv"))
    wb  = pd.read_csv(os.path.join(PROCESSED,"monthly_wb.csv"))
    sdg = pd.read_csv(os.path.join(RAW,"un_sdg_indicators.csv"))

    # ── composite features ──────────────────────────────────────────────────────
    aq["hei"] = build_hei(aq)
    aq["obi"] = build_obi(aq)
    aq["cop"] = build_cop(aq)
    aq["sas"] = build_sas(aq)
    aq = add_lag_rolling(aq)

    # ── merge World Bank ────────────────────────────────────────────────────────
    wb_drop = [c for c in ["wb_code","timestamp","day","hour"] if c in wb.columns]
    feat = aq.merge(wb.drop(columns=wb_drop,errors="ignore"),
                    on=["city","year","month"], how="left")

    # ── SDG targets ─────────────────────────────────────────────────────────────
    sdg_wide = sdg.pivot_table(index=["city","year"],
                                columns="indicator",
                                values="sdg_gap_score").reset_index()
    sdg_wide.columns.name = None
    feat = feat.merge(sdg_wide, on=["city","year"], how="left")

    # forward-fill monthly
    for cl in SDG_CLUSTERS:
        if cl in feat.columns:
            feat[cl] = feat.groupby("city")[cl].transform(
                lambda s: s.interpolate("linear").ffill().bfill())

    feat = feat.dropna(subset=list(SDG_CLUSTERS.keys())).reset_index(drop=True)

    # ── report ──────────────────────────────────────────────────────────────────
    non_feat = {"city","wb_code","year","month","timestamp","day","hour"} | set(SDG_CLUSTERS.keys())
    feature_cols = [c for c in feat.columns if c not in non_feat
                    and feat[c].dtype in ("float64","int64","float32","int32")]

    print(f"\n  Feature matrix  : {feat.shape[0]:,} rows × {len(feature_cols)} features")
    print(f"\n  {'Feature':<38s}  {'Mean':>8}  {'Std':>8}")
    print(f"  {'-'*58}")
    for c in feature_cols:
        print(f"  {c:<38s}  {feat[c].mean():8.3f}  {feat[c].std():8.3f}")

    print(f"\n  Target cluster statistics:")
    for cl in SDG_CLUSTERS:
        print(f"    {cl:<30s}  mean={feat[cl].mean():.1f}  "
              f"std={feat[cl].std():.1f}  "
              f"min={feat[cl].min():.1f}  max={feat[cl].max():.1f}")

    feat.to_csv(os.path.join(PROCESSED,"feature_matrix.csv"), index=False)
    print(f"\n  Saved → data/processed/feature_matrix.csv")

if __name__=="__main__":
    main()
