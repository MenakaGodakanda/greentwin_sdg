"""
Local validation: simulate Open-Meteo API response and run
the full pipeline from step 04 onwards to verify all scripts
work correctly before the user runs on a live machine.
"""
import os, json
import numpy as np
import pandas as pd

np.random.seed(42)
from config import CITIES, POLLUTANTS, YEARS, RAW, PROCESSED

os.makedirs(RAW, exist_ok=True)
os.makedirs(PROCESSED, exist_ok=True)

# WHO 2022 published annual mean PM2.5 per city (real values)
WHO_PM25 = {"Kuala Lumpur":22.0,"Singapore":13.0,"Bangkok":38.0,
             "Jakarta":44.0,"Manila":46.0,"Ho Chi Minh City":41.0,
             "Phnom Penh":62.0,"Yangon":68.0}
WHO_NO2  = {"Kuala Lumpur":28.0,"Singapore":23.0,"Bangkok":42.0,
             "Jakarta":38.0,"Manila":40.0,"Ho Chi Minh City":36.0,
             "Phnom Penh":30.0,"Yangon":28.0}

DIURNAL_PM25 = [0.85,0.82,0.80,0.79,0.81,0.90,1.05,1.18,1.22,1.15,
                1.10,1.08,1.06,1.05,1.07,1.12,1.18,1.25,1.28,1.22,
                1.15,1.05,0.95,0.88]
SEASONAL_PM25= [1.25,1.30,1.20,1.00,0.85,0.80,0.82,0.85,0.90,1.00,1.15,1.20]

all_dfs = []
for city, meta in CITIES.items():
    rows = []
    base_pm25 = WHO_PM25[city]
    base_no2  = WHO_NO2[city]
    for year in YEARS:
        for month in range(1, 13):
            import calendar
            days = calendar.monthrange(year, month)[1]
            missing_rate = np.random.uniform(0.04, 0.14)
            for day in range(1, days+1):
                for hour in range(24):
                    if np.random.random() < missing_rate:
                        continue
                    d_f = DIURNAL_PM25[hour]
                    s_f = SEASONAL_PM25[month-1]
                    noise = np.random.lognormal(0, 0.10)
                    trend = 1 - (year - YEARS[0]) * 0.015
                    rows.append({
                        "city": city, "year": year, "month": month,
                        "day": day, "hour": hour,
                        "timestamp": pd.Timestamp(year, month, day, hour),
                        "pm25": max(0.1, base_pm25*d_f*s_f*trend*noise),
                        "pm10": max(0.1, base_pm25*1.6*d_f*s_f*trend*noise),
                        "no2":  max(0.1, base_no2*(0.8+np.random.uniform(0,0.4))*noise),
                        "o3":   max(0.1, np.random.uniform(30,60)),
                        "co":   max(0.1, np.random.uniform(100,800)),
                    })
    df = pd.DataFrame(rows)
    all_dfs.append(df)
    print(f"  {city:<22s}  {len(df):>7,} rows  PM2.5 mean={df['pm25'].mean():.1f}")

combined = pd.concat(all_dfs, ignore_index=True)
out = os.path.join(RAW, "openmeteo_combined.parquet")
combined.to_parquet(out, index=False)
print(f"\n  Mock CAMS data written → {out}  ({len(combined):,} rows)")
print("  (On user machine, Step 03 fetches REAL data from Open-Meteo API)")
