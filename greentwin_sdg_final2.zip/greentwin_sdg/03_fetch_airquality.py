"""
GreenTwin-SDG  ·  Step 03 — Real Air Quality Data (Open-Meteo / CAMS)
======================================================================
Fetches REAL hourly air quality data via the Open-Meteo Air Quality API.

  • URL    : https://air-quality-api.open-meteo.com
  • Cost   : FREE — no API key, no registration, no rate-limit issues
    for our 8 city requests
  • Source : Copernicus Atmosphere Monitoring Service (CAMS) reanalysis
    and near-realtime forecasts, assimilated from satellite observations
    and ground monitoring stations.  Widely used in peer-reviewed
    atmospheric research.
  • Coverage: Global, hourly, 2020 – present
  • Variables: PM2.5, PM10, NO2, O3, CO  (all µg/m³)

Outputs:
  data/raw/openmeteo_hourly_<city>.parquet
  data/raw/openmeteo_combined.parquet
  data/raw/fetch_log.txt
"""

import os, sys, time, json
import requests
import pandas as pd
import numpy as np
from datetime import datetime
from config import CITIES, OPENMETEO_VARS, POLLUTANTS, QC_LIMITS, YEARS, RAW, SEED

BASE_URL = "https://air-quality-api.open-meteo.com/v1/air-quality"

# Canonical variable list for the API call
HOURLY_VARS = ",".join(OPENMETEO_VARS.keys())   # pm2_5,pm10,nitrogen_dioxide,ozone,carbon_monoxide

def build_url(lat: float, lon: float, start: str, end: str) -> str:
    return (f"{BASE_URL}?latitude={lat}&longitude={lon}"
            f"&hourly={HOURLY_VARS}"
            f"&start_date={start}&end_date={end}"
            f"&timezone=auto")

def fetch_city(city: str, meta: dict, retries: int = 3) -> pd.DataFrame | None:
    """
    Fetch hourly air quality for one city.
    The API accepts multi-year date ranges in a single request.
    Splits into yearly chunks to stay within API response limits.
    """
    lat, lon = meta["lat"], meta["lon"]
    chunks   = []

    for year in YEARS:
        start = f"{year}-01-01"
        end   = f"{year}-12-31"
        url   = build_url(lat, lon, start, end)

        for attempt in range(retries):
            try:
                r = requests.get(url, timeout=30)
                r.raise_for_status()
                data = r.json()
                break
            except requests.exceptions.Timeout:
                print(f"    Timeout (attempt {attempt+1}/{retries}) — retrying …")
                time.sleep(3)
                data = None
            except requests.exceptions.HTTPError as e:
                print(f"    HTTP {r.status_code}: {e}")
                data = None
                break
            except Exception as e:
                print(f"    Error: {e}")
                data = None
                break

        if not data or "hourly" not in data:
            print(f"    {year}: no data returned")
            continue

        h = data["hourly"]
        df = pd.DataFrame({"timestamp": pd.to_datetime(h["time"])})

        for api_name, canon in OPENMETEO_VARS.items():
            df[canon] = pd.to_numeric(
                pd.Series(h.get(api_name, [None] * len(df))),
                errors="coerce")

        df["city"]  = city
        df["year"]  = df["timestamp"].dt.year
        df["month"] = df["timestamp"].dt.month
        df["day"]   = df["timestamp"].dt.day
        df["hour"]  = df["timestamp"].dt.hour

        n_valid = df["pm25"].notna().sum()
        print(f"    {year}: {len(df):,} hours  |  PM2.5 valid={n_valid:,}  "
              f"mean={df['pm25'].mean():.1f} µg/m³")
        chunks.append(df)
        time.sleep(0.5)   # polite pause between years

    return pd.concat(chunks, ignore_index=True) if chunks else None

def apply_qc(df: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Flag physically implausible readings as NaN."""
    report = {}
    for poll, (lo, hi) in QC_LIMITS.items():
        if poll not in df.columns:
            continue
        bad  = (df[poll] < lo) | (df[poll] > hi)
        n_bad = int(bad.sum())
        n_tot = int(df[poll].notna().sum())
        df.loc[bad, poll] = np.nan
        report[poll] = {"flagged": n_bad, "total": n_tot,
                        "pct": round(n_bad / max(n_tot, 1) * 100, 3)}
    return df, report

def main():
    os.makedirs(RAW, exist_ok=True)
    log_lines = [
        "GreenTwin-SDG  ·  Open-Meteo Air Quality Fetch Log",
        f"Run time  : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"API source: Copernicus Atmosphere Monitoring Service (CAMS)",
        f"No API key required. Data is real reanalysis/NRT output.",
        "=" * 60, ""
    ]

    all_dfs = []
    print(f"\n  Source : Open-Meteo Air Quality API (CAMS reanalysis)")
    print(f"  Period : {YEARS[0]}–{YEARS[-1]}")
    print(f"  Cities : {len(CITIES)}\n")

    for city, meta in CITIES.items():
        print(f"  [{city}]  lat={meta['lat']}  lon={meta['lon']}")
        df = fetch_city(city, meta)

        if df is None or df.empty:
            print(f"    ✗ No data fetched — check internet connection")
            log_lines.append(f"{city}: FAILED (no data)")
            continue

        # QC filtering
        df, qc = apply_qc(df)

        # Save per-city parquet
        city_fname = city.lower().replace(" ", "_")
        city_path  = os.path.join(RAW, f"openmeteo_hourly_{city_fname}.parquet")
        df.to_parquet(city_path, index=False)
        all_dfs.append(df)

        dci = df["pm25"].notna().sum() / max(len(df), 1) * 100
        print(f"    ✓  {len(df):,} hourly records  |  DCI={dci:.1f}%  "
              f"|  saved → {os.path.basename(city_path)}")
        log_lines.append(
            f"{city}: {len(df):,} records  |  DCI={dci:.1f}%  |  "
            f"PM2.5 mean={df['pm25'].mean():.1f} µg/m³  |  "
            f"PM2.5 flagged={qc.get('pm25',{}).get('flagged',0)}")

    if not all_dfs:
        print("\n  ERROR: No data fetched for any city.")
        print("  Check your internet connection and that the domain")
        print("  air-quality-api.open-meteo.com is reachable.")
        sys.exit(1)

    # Combined parquet
    combined  = pd.concat(all_dfs, ignore_index=True)
    comb_path = os.path.join(RAW, "openmeteo_combined.parquet")
    combined.to_parquet(comb_path, index=False)

    # Summary
    print(f"\n{'='*58}")
    print(f"  Cities fetched     : {combined['city'].nunique()} / {len(CITIES)}")
    print(f"  Total hourly rows  : {len(combined):,}")
    print(f"  Years covered      : {sorted(combined['year'].unique())}")
    print(f"\n  Pollutant summary (µg/m³):")
    for p in POLLUTANTS:
        if p in combined.columns:
            print(f"    {p:6s}  mean={combined[p].mean():8.2f}  "
                  f"std={combined[p].std():7.2f}  "
                  f"missing={combined[p].isna().mean()*100:.1f}%")

    log_lines += ["", "Combined summary:",
                  f"  Total rows : {len(combined):,}",
                  f"  Cities     : {sorted(combined['city'].unique())}"]
    log_path = os.path.join(RAW, "fetch_log.txt")
    with open(log_path, "w") as f:
        f.write("\n".join(log_lines))

    print(f"\n  Combined  → {comb_path}")
    print(f"  Log       → {log_path}")

if __name__ == "__main__":
    main()
