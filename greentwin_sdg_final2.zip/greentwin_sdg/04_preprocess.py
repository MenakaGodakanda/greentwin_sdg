"""
GreenTwin-SDG  ·  Step 04 — Pre-processing
===========================================
Reads the real Open-Meteo CAMS data, applies QC,
aggregates to monthly city means, log-transforms,
and interpolates World Bank annual data to monthly.

Inputs  : data/raw/openmeteo_combined.parquet
          data/raw/worldbank_wdi.csv
Outputs : data/processed/monthly_aq.csv
          data/processed/monthly_wb.csv
          data/processed/preprocessing_report.txt
"""
import os, sys, warnings
import numpy as np
import pandas as pd
import calendar
warnings.filterwarnings("ignore")

from config import CITIES, WB_INDICATORS, POLLUTANTS, QC_LIMITS, YEARS, RAW, PROCESSED

def load_openmeteo(path: str) -> pd.DataFrame:
    df = pd.read_parquet(path)
    # Ensure year/month columns exist
    if "timestamp" in df.columns:
        df["timestamp"] = pd.to_datetime(df["timestamp"])
        df["year"]  = df["timestamp"].dt.year
        df["month"] = df["timestamp"].dt.month
    df = df[df["year"].isin(YEARS)]
    return df

def compute_dci(df: pd.DataFrame) -> pd.DataFrame:
    """Data Completeness Index = valid PM2.5 readings / expected hours per month."""
    cnt = df.groupby(["city","year","month"])["pm25"].count().reset_index()
    cnt.columns = ["city","year","month","valid_hours"]
    def max_h(row):
        return calendar.monthrange(int(row["year"]), int(row["month"]))[1] * 24
    cnt["max_hours"] = cnt.apply(max_h, axis=1)
    cnt["dci"] = (cnt["valid_hours"] / cnt["max_hours"]).clip(0, 1)
    return cnt[["city","year","month","dci"]]

def monthly_agg(df: pd.DataFrame) -> pd.DataFrame:
    agg = df.groupby(["city","year","month"])[POLLUTANTS].mean().reset_index()
    return agg

def log_transform(df: pd.DataFrame) -> pd.DataFrame:
    for p in POLLUTANTS:
        if p in df.columns:
            df[f"log_{p}"] = np.log1p(df[p].clip(lower=0))
    return df

def interpolate_wb_monthly(wb: pd.DataFrame) -> pd.DataFrame:
    wb_cols = [c for c in wb.columns if c not in ("city","wb_code","year")]
    rows = []
    for city in wb["city"].unique():
        sub = wb[wb["city"]==city].sort_values("year")
        for year in YEARS:
            yr_row = sub[sub["year"]==year]
            for month in range(1, 13):
                r = {"city": city, "year": year, "month": month}
                for col in wb_cols:
                    r[col] = float(yr_row[col].values[0]) if not yr_row.empty else np.nan
                rows.append(r)
    monthly = pd.DataFrame(rows).sort_values(["city","year","month"])
    for col in wb_cols:
        monthly[col] = monthly.groupby("city")[col].transform(
            lambda s: s.interpolate("linear").ffill().bfill())
    return monthly

def main():
    os.makedirs(PROCESSED, exist_ok=True)

    # ── Load Open-Meteo data ──────────────────────────────
    comb_path = os.path.join(RAW, "openmeteo_combined.parquet")
    if not os.path.exists(comb_path):
        # Try individual city parquets
        city_files = [os.path.join(RAW, f"openmeteo_hourly_{c.lower().replace(' ','_')}.parquet")
                      for c in CITIES]
        available = [f for f in city_files if os.path.exists(f)]
        if not available:
            print("  ERROR: No Open-Meteo parquet files found.")
            print("  Run step 03 first:  python 03_fetch_airquality.py")
            sys.exit(1)
        aq = pd.concat([pd.read_parquet(f) for f in available], ignore_index=True)
    else:
        print("  Loading openmeteo_combined.parquet ...")
        aq = load_openmeteo(comb_path)

    aq["year"]  = pd.to_numeric(aq["year"],  errors="coerce").astype(int)
    aq["month"] = pd.to_numeric(aq["month"], errors="coerce").astype(int)
    aq = aq[aq["year"].isin(YEARS)]
    print(f"  Raw hourly rows : {len(aq):,}  |  cities : {sorted(aq['city'].unique())}")

    # ── QC ────────────────────────────────────────────────
    print("\n── Step 1: QC filtering")
    for poll, (lo, hi) in QC_LIMITS.items():
        if poll in aq.columns:
            bad = (aq[poll] < lo) | (aq[poll] > hi)
            n_bad = bad.sum()
            aq.loc[bad, poll] = np.nan
            if n_bad:
                print(f"  {poll:6s}  flagged {n_bad:,} outliers")

    # ── DCI ───────────────────────────────────────────────
    print("\n── Step 2: Data Completeness Index")
    dci_df = compute_dci(aq)
    print(f"  DCI range: {dci_df['dci'].min():.2f} – {dci_df['dci'].max():.2f}  "
          f"|  mean: {dci_df['dci'].mean():.3f}")

    # ── Monthly aggregation ────────────────────────────────
    print("\n── Step 3: Monthly aggregation")
    monthly_aq = monthly_agg(aq).merge(dci_df, on=["city","year","month"], how="left")
    print(f"  Monthly AQ rows : {len(monthly_aq):,}")

    # ── Log transform ──────────────────────────────────────
    print("\n── Step 4: Log-transformation")
    monthly_aq = log_transform(monthly_aq)

    # ── World Bank ─────────────────────────────────────────
    wb_path = os.path.join(RAW, "worldbank_wdi.csv")
    if not os.path.exists(wb_path):
        print("\n  ERROR: worldbank_wdi.csv not found. Run step 01 first.")
        sys.exit(1)
    wb = pd.read_csv(wb_path)
    print(f"\n── Step 5: WB annual → monthly ({len(wb):,} annual rows)")
    monthly_wb = interpolate_wb_monthly(wb)

    # ── Save ───────────────────────────────────────────────
    aq_out = os.path.join(PROCESSED, "monthly_aq.csv")
    wb_out = os.path.join(PROCESSED, "monthly_wb.csv")
    monthly_aq.to_csv(aq_out, index=False)
    monthly_wb.to_csv(wb_out, index=False)

    # ── Report ─────────────────────────────────────────────
    lines = [
        "GreenTwin-SDG · Pre-processing Report",
        "Source: Open-Meteo CAMS Reanalysis (REAL data, no API key)",
        "="*52,
        f"Raw hourly records     : {len(aq):,}",
        f"Monthly AQ records     : {len(monthly_aq):,}",
        f"Monthly WB records     : {len(monthly_wb):,}",
        f"Cities                 : {sorted(monthly_aq['city'].unique())}",
        f"Years                  : {sorted(monthly_aq['year'].unique())}",
        "",
        "Monthly pollutant statistics (post-QC, µg/m³):",
    ]
    for p in POLLUTANTS:
        if p in monthly_aq.columns:
            lines.append(f"  {p:6s}  mean={monthly_aq[p].mean():.2f}  "
                         f"std={monthly_aq[p].std():.2f}  "
                         f"missing={monthly_aq[p].isna().mean()*100:.1f}%")
    rpt_path = os.path.join(PROCESSED, "preprocessing_report.txt")
    with open(rpt_path, "w") as f:
        f.write("\n".join(lines))

    print(f"\n{'='*52}")
    print(f"  monthly_aq.csv  ({len(monthly_aq):,} rows)")
    print(f"  monthly_wb.csv  ({len(monthly_wb):,} rows)")
    print(f"  Report → {rpt_path}")
    print(f"\n  Pollutant coverage:")
    for p in POLLUTANTS:
        if p in monthly_aq.columns:
            pct = monthly_aq[p].notna().mean()*100
            print(f"    {p:6s}  {pct:.0f}% non-null")

if __name__ == "__main__":
    main()
