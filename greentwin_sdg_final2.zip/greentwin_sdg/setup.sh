#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════
#  GreenTwin-SDG  ·  Environment Setup  (Ubuntu 22.04+)
#  Run once:  bash setup.sh
# ═══════════════════════════════════════════════════════════
set -e

echo "───────────────────────────────────────────────"
echo "  GreenTwin-SDG  ·  Environment Setup"
echo "───────────────────────────────────────────────"

# 1. System dependencies
echo "[1/5] Installing system packages ..."
sudo apt-get update -qq
sudo apt-get install -y python3 python3-venv python3-pip git curl > /dev/null

# 2. Create virtual environment
echo "[2/5] Creating virtual environment ..."
python3 -m venv venv
source venv/bin/activate

# 3. Upgrade pip
echo "[3/5] Upgrading pip ..."
pip install --upgrade pip setuptools wheel -q

# 4. Install Python dependencies
echo "[4/5] Installing Python packages ..."
pip install -q \
  numpy==1.26.4 \
  pandas==2.2.2 \
  scikit-learn==1.4.2 \
  xgboost==2.0.3 \
  shap==0.45.0 \
  matplotlib==3.8.4 \
  seaborn==0.13.2 \
  requests==2.31.0 \
  joblib==1.4.2 \
  pyarrow==16.1.0

# 5. Create output directories
echo "[5/5] Creating project directories ..."
mkdir -p data/raw data/processed outputs/{figures,models,results}

echo ""
echo "✓  Setup complete!"
echo "   Activate with:  source venv/bin/activate"
echo "   Then run:        bash run_pipeline.sh"
