"""
GreenTwin-SDG  ·  Step 06 — Model Training
============================================
Trains one XGBoost regressor per SDG thematic cluster
using city-stratified 70/15/15 splits and Bayesian
hyperparameter search.  A linear regression baseline
is also trained for comparison.

Inputs  : data/processed/feature_matrix.csv
Outputs : outputs/models/model_<cluster>.json
          outputs/results/training_report.txt
          outputs/results/performance_metrics.csv
"""

import os, json, warnings
import numpy as np
import pandas as pd
import joblib
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import cross_val_score
from xgboost import XGBRegressor
warnings.filterwarnings("ignore")

from config import SDG_CLUSTERS, PROCESSED, MODELS, RESULTS, SEED

FEATURE_EXCLUDE = {"city", "wb_code", "year", "month",
                   "timestamp", "day", "hour"} | set(SDG_CLUSTERS.keys())

def stratified_split(df, city_col="city", seed=SEED):
    """City-stratified 70 / 15 / 15 train / val / test split."""
    cities = df[city_col].unique()
    rng = np.random.default_rng(seed)
    rng.shuffle(cities)
    n = len(cities)
    train_cities = cities[:int(n * 0.70) or max(1, n-2)]
    val_cities   = cities[len(train_cities):len(train_cities) + max(1, int(n * 0.15))]
    test_cities  = cities[len(train_cities) + len(val_cities):]
    return (df[df[city_col].isin(train_cities)],
            df[df[city_col].isin(val_cities)],
            df[df[city_col].isin(test_cities)])

def bayesian_search(X_tr, y_tr, X_val, y_val, n_iter=30, seed=SEED):
    """
    Simplified Bayesian-style random search over XGBoost hyperparameters.
    Returns best params and best validation MAE.
    """
    rng = np.random.default_rng(seed)
    best_mae  = np.inf
    best_params = {}

    for _ in range(n_iter):
        params = {
            "learning_rate":    float(rng.uniform(0.01, 0.30)),
            "max_depth":        int(rng.integers(3, 9)),
            "subsample":        float(rng.uniform(0.60, 1.00)),
            "colsample_bytree": float(rng.uniform(0.60, 1.00)),
            "n_estimators":     200,
            "early_stopping_rounds": 20,
            "random_state":     seed,
            "verbosity":        0,
        }
        model = XGBRegressor(**params)
        model.fit(X_tr, y_tr,
                  eval_set=[(X_val, y_val)],
                  verbose=False)
        preds = model.predict(X_val)
        mae   = mean_absolute_error(y_val, preds)
        if mae < best_mae:
            best_mae    = mae
            best_params = {k: v for k, v in params.items()
                           if k not in ("early_stopping_rounds", "verbosity")}
    return best_params, best_mae

def evaluate(y_true, y_pred, label):
    mae  = mean_absolute_error(y_true, y_pred)
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    r2   = r2_score(y_true, y_pred)
    print(f"    {label:<10s}  MAE={mae:.2f}  RMSE={rmse:.2f}  R²={r2:.3f}")
    return {"split": label, "mae": mae, "rmse": rmse, "r2": r2}

def main():
    os.makedirs(MODELS, exist_ok=True)
    os.makedirs(RESULTS, exist_ok=True)

    df = pd.read_csv(os.path.join(PROCESSED, "feature_matrix.csv"))
    feature_cols = [c for c in df.columns if c not in FEATURE_EXCLUDE
                    and df[c].dtype in (float, "float64", int, "int64")]

    print(f"  Features used : {len(feature_cols)}")
    print(f"  Total rows    : {len(df):,}")
    print(f"  Cities        : {sorted(df['city'].unique())}")

    all_metrics = []
    report_lines = ["GreenTwin-SDG · Training Report", "=" * 60, ""]

    for cluster_name in SDG_CLUSTERS.keys():
        print(f"\n{'─'*60}")
        print(f"  Cluster : {cluster_name}")

        sub = df[feature_cols + ["city", cluster_name]].dropna()
        X   = sub[feature_cols].values
        y   = sub[cluster_name].values

        train_df, val_df, test_df = stratified_split(sub)
        X_tr, y_tr = train_df[feature_cols].values, train_df[cluster_name].values
        X_va, y_va = val_df[feature_cols].values,   val_df[cluster_name].values
        X_te, y_te = test_df[feature_cols].values,  test_df[cluster_name].values

        print(f"    Train: {len(X_tr):>5,}  Val: {len(X_va):>5,}  Test: {len(X_te):>5,}")
        print(f"    Train cities: {sorted(train_df['city'].unique())}")
        print(f"    Test  cities: {sorted(test_df['city'].unique())}")

        # ── Bayesian hyperparameter search ──────────────────────────────────
        print("    Bayesian search (30 iterations) ...")
        best_params, val_mae = bayesian_search(X_tr, y_tr, X_va, y_va)
        print(f"    Best val MAE : {val_mae:.3f}")
        print(f"    Best params  : lr={best_params['learning_rate']:.3f}  "
              f"depth={best_params['max_depth']}  "
              f"sub={best_params['subsample']:.2f}")

        # ── Final model on train + val ───────────────────────────────────────
        X_tv = np.vstack([X_tr, X_va])
        y_tv = np.concatenate([y_tr, y_va])
        final_model = XGBRegressor(**best_params, verbosity=0)
        final_model.fit(X_tv, y_tv)

        # ── Baseline: Ridge regression ───────────────────────────────────────
        scaler   = StandardScaler()
        X_tv_sc  = scaler.fit_transform(X_tv)
        X_te_sc  = scaler.transform(X_te)
        baseline = Ridge()
        baseline.fit(X_tv_sc, y_tv)
        bl_pred  = baseline.predict(X_te_sc)
        xgb_pred = final_model.predict(X_te)

        # ── Evaluation ──────────────────────────────────────────────────────
        print("    Test-set performance:")
        m_xgb = evaluate(y_te, xgb_pred, "XGBoost")
        m_bl  = evaluate(y_te, bl_pred,  "Ridge")
        delta_mae = (m_bl["mae"] - m_xgb["mae"]) / m_bl["mae"] * 100
        print(f"    MAE improvement vs Ridge : {delta_mae:.1f}%")

        m_xgb.update({"cluster": cluster_name, "model": "XGBoost",
                       "delta_mae_pct": round(delta_mae, 1),
                       "best_lr": best_params["learning_rate"],
                       "best_depth": best_params["max_depth"]})
        m_bl.update({"cluster": cluster_name, "model": "Ridge",
                      "delta_mae_pct": 0.0})
        all_metrics.extend([m_xgb, m_bl])

        # ── Save model and params ────────────────────────────────────────────
        model_path = os.path.join(MODELS, f"model_{cluster_name}.json")
        final_model.save_model(model_path)

        meta_path = os.path.join(MODELS, f"meta_{cluster_name}.json")
        with open(meta_path, "w") as f:
            json.dump({"feature_cols": feature_cols,
                       "best_params": best_params,
                       "test_cities": sorted(test_df["city"].unique()),
                       "val_mae": val_mae}, f, indent=2)

        # Save test predictions for SHAP
        test_df = test_df.copy()
        test_df["xgb_pred"] = xgb_pred
        test_df["ridge_pred"] = bl_pred
        pred_path = os.path.join(RESULTS, f"test_preds_{cluster_name}.csv")
        test_df.to_csv(pred_path, index=False)

        report_lines += [
            f"Cluster: {cluster_name}",
            f"  Train/Val/Test : {len(X_tr)}/{len(X_va)}/{len(X_te)}",
            f"  XGBoost MAE  : {m_xgb['mae']:.3f}",
            f"  XGBoost RMSE : {m_xgb['rmse']:.3f}",
            f"  XGBoost R²   : {m_xgb['r2']:.3f}",
            f"  Ridge MAE    : {m_bl['mae']:.3f}",
            f"  MAE improve  : {delta_mae:.1f}%",
            f"  Best LR      : {best_params['learning_rate']:.4f}",
            f"  Best depth   : {best_params['max_depth']}",
            "",
        ]

    # ── Summary table ────────────────────────────────────────────────────────
    metrics_df = pd.DataFrame(all_metrics)
    xgb_only = metrics_df[metrics_df["model"] == "XGBoost"][
        ["cluster", "mae", "rmse", "r2", "delta_mae_pct"]]
    xgb_only.columns = ["Cluster", "MAE", "RMSE", "R²", "Δ vs Baseline (%)"]
    xgb_only = xgb_only.round(3)

    print(f"\n{'='*60}")
    print("  FINAL PERFORMANCE SUMMARY (XGBoost, test set)")
    print(f"{'='*60}")
    print(xgb_only.to_string(index=False))

    csv_path = os.path.join(RESULTS, "performance_metrics.csv")
    metrics_df.to_csv(csv_path, index=False)

    rpt_path = os.path.join(RESULTS, "training_report.txt")
    with open(rpt_path, "w") as f:
        f.write("\n".join(report_lines))

    print(f"\n  Models saved  → {MODELS}")
    print(f"  Metrics CSV   → {csv_path}")
    print(f"  Report        → {rpt_path}")

if __name__ == "__main__":
    main()
