"""
GreenTwin-SDG v1  ·  Regenerate Fig 2 & Fig 3
===============================================
Fig 1 (architecture) removed per user request.
Fig 3 rebuilt from full-dataset predictions
(all 8 cities x all months) instead of test-set only.

Fully self-contained — generates allcity_preds_*.csv
internally before drawing the figures.
"""

import os, sys, json, warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.colors as mcolors
from matplotlib.lines import Line2D
warnings.filterwarnings("ignore")

from config import SDG_CLUSTERS, PROCESSED, MODELS, RESULTS, FIGS

os.makedirs(FIGS, exist_ok=True)
os.makedirs(RESULTS, exist_ok=True)
plt.rcParams.update({"font.family":     "DejaVu Serif",
                     "axes.spines.top": False,
                     "axes.spines.right": False})

CITIES_ORDER = ["Kuala Lumpur", "Singapore", "Bangkok", "Jakarta",
                "Manila", "Ho Chi Minh City", "Phnom Penh", "Yangon"]
MONTHS = ["Jan","Feb","Mar","Apr","May","Jun",
          "Jul","Aug","Sep","Oct","Nov","Dec"]

# ══════════════════════════════════════════════════════════════
# STEP A — Generate full-dataset predictions (all 8 cities)
# ══════════════════════════════════════════════════════════════
def generate_allcity_preds():
    """
    Runs every trained XGBoost model over the complete feature
    matrix and writes allcity_preds_<cluster>.csv to outputs/results/.
    Called automatically at the start of main().
    """
    fm_path = os.path.join(PROCESSED, "feature_matrix.csv")
    if not os.path.exists(fm_path):
        print("  ERROR: feature_matrix.csv not found.")
        print("  Run steps 01-05 first, then re-run this script.")
        sys.exit(1)

    try:
        from xgboost import XGBRegressor
    except ImportError:
        print("  ERROR: xgboost not installed. Run: pip install xgboost")
        sys.exit(1)

    fm = pd.read_csv(fm_path)
    print(f"  Feature matrix loaded: {len(fm):,} rows  "
          f"cities={sorted(fm['city'].unique())}")

    for cluster in SDG_CLUSTERS.keys():
        out_path   = os.path.join(RESULTS, f"allcity_preds_{cluster}.csv")
        model_path = os.path.join(MODELS,  f"model_{cluster}.json")
        meta_path  = os.path.join(MODELS,  f"meta_{cluster}.json")

        if not os.path.exists(model_path):
            print(f"  SKIP {cluster} — model file not found "
                  f"(run step 06 first)")
            continue
        if not os.path.exists(meta_path):
            print(f"  SKIP {cluster} — meta file not found")
            continue

        model = XGBRegressor()
        model.load_model(model_path)

        with open(meta_path) as f:
            meta = json.load(f)
        feature_cols = meta["feature_cols"]

        # Keep all rows with complete feature data
        available = [c for c in feature_cols if c in fm.columns]
        missing   = [c for c in feature_cols if c not in fm.columns]
        if missing:
            print(f"  WARN {cluster}: {len(missing)} feature(s) not in "
                  f"feature_matrix — will be zero-filled")
            for c in missing:
                fm[c] = 0.0

        sub = fm[available + ["city", "year", "month"] +
                 ([cluster] if cluster in fm.columns else [])].copy()
        sub = sub.dropna(subset=available)
        X   = sub[available].values

        sub["xgb_pred"] = model.predict(X).clip(0, 100)
        sub.to_csv(out_path, index=False)
        print(f"  {cluster:<30s} {len(sub):>4,} rows  "
              f"cities={sorted(sub['city'].unique())}")

    print()


# ══════════════════════════════════════════════════════════════
# Helper: pick best cluster by lowest test MAE
# ══════════════════════════════════════════════════════════════
def best_cluster() -> str:
    mp = os.path.join(RESULTS, "performance_metrics.csv")
    if not os.path.exists(mp):
        return list(SDG_CLUSTERS.keys())[0]
    df  = pd.read_csv(mp)
    xgb = df[df["model"] == "XGBoost"]
    if xgb.empty:
        return list(SDG_CLUSTERS.keys())[0]
    return xgb.loc[xgb["mae"].idxmin(), "cluster"]


# ══════════════════════════════════════════════════════════════
# FIG 2 — SHAP Beeswarm (best cluster)
# ══════════════════════════════════════════════════════════════
def make_fig2(cluster: str):
    shap_path = os.path.join(RESULTS, f"shap_values_{cluster}.csv")
    imp_path  = os.path.join(RESULTS, f"shap_importance_{cluster}.csv")

    if not os.path.exists(shap_path) or not os.path.exists(imp_path):
        print(f"  Fig 2 SKIP — SHAP files not found for {cluster}.")
        print(f"  Run step 07 first: python 07_shap_analysis.py")
        return

    shap_df = pd.read_csv(shap_path)
    imp_df  = pd.read_csv(imp_path)

    top_n    = min(11, len(imp_df))
    top_feat = imp_df.head(top_n)["feature"].tolist()

    LABELS = {
        "pm25": "PM\u2082.\u2085 Monthly Mean",
        "pm10": "PM\u2081\u2080 Monthly Mean",
        "no2":  "NO\u2082 Monthly Mean",
        "o3":   "O\u2083 Monthly Mean",
        "co":   "CO Monthly Mean",
        "log_pm25": "Log PM\u2082.\u2085",
        "log_pm10": "Log PM\u2081\u2080",
        "log_no2":  "Log NO\u2082 Concentration",
        "log_o3":   "Log O\u2083",
        "log_co":   "Log CO",
        "hei": "Health Exposure Index (HEI)",
        "obi": "Ozone Burden Index (OBI)",
        "cop": "CO Proxy (COP)",
        "sas": "Seasonal Anomaly Score (SAS)",
        "dci": "Data Completeness Index (DCI)",
        "log_pm25_roll3": "PM\u2082.\u2085 3-month Rolling Mean",
        "log_pm25_roll6": "PM\u2082.\u2085 6-month Rolling Mean",
        "log_pm25_lag1":  "Log PM\u2082.\u2085 Lag-1 Month",
        "log_no2_roll3":  "NO\u2082 3-month Rolling Mean",
        "log_no2_roll6":  "NO\u2082 6-month Rolling Mean",
        "log_no2_lag1":   "Log NO\u2082 Lag-1 Month",
        "hei_roll3": "HEI 3-month Rolling Mean",
        "hei_roll6": "HEI 6-month Rolling Mean",
        "hei_lag1":  "HEI Lag-1 Month",
        "electrification_rate":  "Electrification Rate",
        "clean_cooking_access":  "Clean Cooking Access",
        "safe_water_access":     "Safe Water Access",
        "urban_population_pct":  "Urban Population %",
        "pm25_national_mean":    "PM\u2082.\u2085 National Mean (WB)",
    }

    fig, ax = plt.subplots(figsize=(7.5, 5.4))
    cmap    = plt.cm.RdBu_r
    np.random.seed(42)

    for rank, feat in enumerate(reversed(top_feat)):
        sv      = shap_df[feat].values if feat in shap_df.columns \
                  else np.zeros(len(shap_df))
        fv      = shap_df[feat].fillna(0).values if feat in shap_df.columns \
                  else np.zeros(len(shap_df))
        fv_norm = (fv - fv.min()) / (np.ptp(fv) + 1e-9)
        yj      = rank + np.random.uniform(-0.25, 0.25, len(sv))
        ax.scatter(sv, yj, c=fv_norm, cmap=cmap, vmin=0, vmax=1,
                   alpha=0.45, s=12, linewidths=0, zorder=3)

    ax.axvline(0, color="#444", lw=0.9, zorder=2)
    for i in range(top_n):
        if i % 2 == 0:
            ax.axhspan(i - 0.5, i + 0.5, color="#F4F7FA", zorder=1)

    ax.set_yticks(range(top_n))
    ax.set_yticklabels(
        [LABELS.get(f, f.replace("_", " ").title()) for f in reversed(top_feat)],
        fontsize=8.5)
    ax.set_xlabel("SHAP Value  (impact on SDG gap score prediction)", fontsize=9)
    ax.set_ylim(-0.7, top_n - 0.3)
    ax.tick_params(axis="x", labelsize=8)

    # Mean |SHAP| bar strip
    ax2 = ax.twinx(); ax2.set_ylim(ax.get_ylim()); ax2.set_yticks([])
    imp_vals = [float(imp_df.loc[imp_df["feature"]==f, "mean_abs_shap"].values[0])
                if f in imp_df["feature"].values else 0.0
                for f in reversed(top_feat)]
    total_shap = max(sum(imp_vals), 1e-9)
    x_off = ax.get_xlim()[1] * 0.68
    for i, mv in enumerate(imp_vals):
        ax2.barh(i, mv, left=x_off, height=0.38,
                 color="#1A3A5C", alpha=0.80, zorder=4)
        ax2.text(x_off + mv + abs(x_off)*0.02, i,
                 f"{mv:.2f}", va="center", fontsize=6.6, color="#1A3A5C")
    ax2.text(x_off + max(imp_vals)*0.5, top_n - 0.05,
             "Mean\n|SHAP|", ha="center", va="top",
             fontsize=7.2, color="#1A3A5C", fontweight="bold")

    # Colourbar
    sm   = plt.cm.ScalarMappable(cmap=cmap, norm=mcolors.Normalize(0, 1))
    sm.set_array([])
    cbar = plt.colorbar(sm, ax=ax, pad=0.01, fraction=0.024, aspect=28)
    cbar.set_label("Feature value\n(low \u2192 high)", fontsize=7.8)
    cbar.set_ticks([0, 0.5, 1])
    cbar.set_ticklabels(["Low", "Mid", "High"])
    cbar.ax.tick_params(labelsize=7.4)

    # Top-3 annotation bracket
    top3_pct = sum(imp_vals[-3:]) / total_shap * 100
    for y in [top_n - 0.55, top_n - 3.45]:
        ax.axhline(y, color="#B85C00", lw=0.75, ls="--", xmax=0.42, zorder=5)
    x_ann = ax.get_xlim()[0] * 0.90
    ax.annotate("", xy=(x_ann, top_n - 0.55), xytext=(x_ann, top_n - 3.45),
                arrowprops=dict(arrowstyle="<->", color="#B85C00", lw=1.3))
    ax.text(x_ann * 0.72, top_n - 2.0,
            f"Top 3\n({top3_pct:.0f}% var.)",
            va="center", fontsize=7.2, color="#B85C00", fontweight="bold")

    ax.set_title(
        f"SHAP Beeswarm Summary \u2014 {cluster.replace('_',' ')} Cluster\n"
        f"(n = {len(shap_df):,} city-month records, "
        f"{sorted(shap_df['year'].unique()) if 'year' in shap_df.columns else '2020-2024'})",
        fontsize=9.5, fontweight="bold", pad=8)

    plt.tight_layout(pad=0.6)
    out = os.path.join(FIGS, "Fig2_SHAP_Beeswarm.png")
    fig.savefig(out, dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print(f"  Fig 2 saved  \u2192  {out}")


# ══════════════════════════════════════════════════════════════
# FIG 3 — SDG Gap Heatmap (all 8 cities, full monthly grid)
# ══════════════════════════════════════════════════════════════
def make_fig3(cluster: str):
    pred_path = os.path.join(RESULTS, f"allcity_preds_{cluster}.csv")
    if not os.path.exists(pred_path):
        print(f"  Fig 3 SKIP \u2014 {os.path.basename(pred_path)} not found.")
        print(f"  This should have been created in Step A. "
              f"Check that model files exist in {MODELS}/")
        return

    preds = pd.read_csv(pred_path)
    preds["year"]  = pd.to_numeric(preds["year"],  errors="coerce").fillna(2022).astype(int)
    preds["month"] = pd.to_numeric(preds["month"], errors="coerce").fillna(7).astype(int)

    # Use most recent year available
    plot_year   = int(preds["year"].max())
    preds_yr    = preds[preds["year"] == plot_year]

    # Cities present in the prediction file
    cities_avail = [c for c in CITIES_ORDER if c in preds_yr["city"].values]
    if not cities_avail:
        cities_avail = sorted(preds_yr["city"].unique())
    n_cities = len(cities_avail)

    pred_mat = np.full((n_cities, 12), np.nan)
    gt_mat   = np.full((n_cities, 12), np.nan)

    for ci, city in enumerate(cities_avail):
        cd = preds_yr[preds_yr["city"] == city]
        for mi in range(1, 13):
            md = cd[cd["month"] == mi]
            if not md.empty:
                pred_mat[ci, mi - 1] = round(float(md["xgb_pred"].mean()), 0)
        # UN annual value: mid-year convention (July)
        if cluster in cd.columns:
            gt_vals = cd[cluster].dropna()
            if not gt_vals.empty:
                gt_mat[ci, 6] = round(float(gt_vals.mean()), 0)

    cmap = mcolors.LinearSegmentedColormap.from_list(
        "sdg_gap", ["#FFFFFF","#FEE5D9","#FC9272","#DE2D26","#67000D"])
    vmin, vmax = 0, 85

    fig, axes = plt.subplots(1, 2, figsize=(12.5, 0.65 * n_cities + 2.5),
                             gridspec_kw={"wspace": 0.06})

    for ax, matrix, title in zip(
        axes,
        [pred_mat, gt_mat],
        [f"GreenTwin-SDG\n(Monthly continuous estimates, {plot_year})",
         f"UN SDG Database\n(Annual reported value, {plot_year})"]
    ):
        ax.imshow(matrix, aspect="auto", cmap=cmap,
                  vmin=vmin, vmax=vmax, interpolation="nearest")
        ax.set_xticks(range(12))
        ax.set_xticklabels(MONTHS, fontsize=8)
        ax.set_yticks(range(n_cities))
        ax.set_yticklabels(cities_avail if ax is axes[0] else [],
                           fontsize=9)
        ax.set_title(title, fontsize=9.2, fontweight="bold")
        ax.set_xlabel(f"Month ({plot_year})", fontsize=8.4)

        for ci in range(n_cities):
            for mi in range(12):
                v = matrix[ci, mi]
                if not np.isnan(v):
                    tc = "white" if v > 52 else "#1a1a1a"
                    fw = "bold"  if ax is axes[1] else "normal"
                    ax.text(mi, ci, f"{v:.0f}", ha="center", va="center",
                            fontsize=7, color=tc, fontweight=fw)
                else:
                    ax.text(mi, ci, "\u2014", ha="center", va="center",
                            fontsize=6.8, color="#BBBBBB")

        # Highlight two highest-gap cities (Phnom Penh + Yangon)
        for row_name in ["Phnom Penh", "Yangon"]:
            if row_name in cities_avail:
                row = cities_avail.index(row_name)
                ax.add_patch(plt.Rectangle((-0.5, row - 0.5), 12, 1,
                    fill=False, edgecolor="#FF8C00", lw=2.0, zorder=5))

    # Shared colourbar
    cbar_ax = fig.add_axes([0.92, 0.18, 0.016, 0.64])
    sm = plt.cm.ScalarMappable(cmap=cmap, norm=mcolors.Normalize(vmin, vmax))
    sm.set_array([])
    cb = fig.colorbar(sm, cax=cbar_ax)
    cb.set_label("SDG Gap Score\n(0\u2009=\u2009on track\n85\u2009=\u2009large gap)",
                 fontsize=8)
    cb.ax.tick_params(labelsize=7.5)

    legend_els = [
        Line2D([0],[0], color="#FF8C00", lw=2,
               label="Highest-gap cities (Yangon, Phnom Penh)"),
        mpatches.Patch(facecolor="white", edgecolor="#BBBBBB",
                       label="No official UN data available (\u2014)"),
    ]
    fig.legend(handles=legend_els, loc="lower center",
               bbox_to_anchor=(0.47, -0.04), ncol=2,
               fontsize=8, frameon=True, edgecolor="#CCCCCC")

    fig.suptitle(
        f"City-Level SDG Gap Score Heatmap ({plot_year})  |  "
        f"GreenTwin-SDG vs. UN SDG Database\n"
        f"Cluster: {cluster.replace('_',' ')}",
        fontsize=10, fontweight="bold", y=1.02)

    out = os.path.join(FIGS, "Fig3_SDG_Heatmap.png")
    fig.savefig(out, dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print(f"  Fig 3 saved  \u2192  {out}")


# ══════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════
if __name__ == "__main__":
    print("\n\u2500\u2500 Step A: Generating full-dataset predictions (all cities)")
    generate_allcity_preds()

    cl = best_cluster()
    print(f"  Best-performing cluster : {cl}")

    print("\n\u2500\u2500 Figure 2: SHAP Beeswarm")
    make_fig2(cl)

    print("\n\u2500\u2500 Figure 3: SDG Gap Heatmap (all 8 cities)")
    make_fig3(cl)

    print(f"\n  Done. Figures \u2192 {FIGS}/")
