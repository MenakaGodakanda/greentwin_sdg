"""
GreenTwin-SDG  ·  Step 01 — World Bank WDI
===========================================
Fetches real World Bank indicator data.

  • API : https://api.worldbank.org/v2/  (free, no key)
  • Fallback : published World Bank country profiles 2020-2024
    used when the API is unreachable.

Output : data/raw/worldbank_wdi.csv
"""
import os, time
import requests
import pandas as pd
import numpy as np
from config import CITIES, WB_INDICATORS, WB_FALLBACK, YEARS, RAW

WB_URL = ("https://api.worldbank.org/v2/country/{code}"
          "/indicator/{ind}?format=json&date={y0}:{y1}&per_page=100")

def try_api(code: str, indicator: str) -> dict | None:
    url = WB_URL.format(code=code, ind=indicator, y0=YEARS[0], y1=YEARS[-1])
    try:
        r = requests.get(url, timeout=8)
        r.raise_for_status()
        payload = r.json()
        if len(payload) < 2 or not payload[1]:
            return None
        return {int(e["date"]): e["value"]
                for e in payload[1]
                if e["value"] is not None and int(e["date"]) in YEARS}
    except Exception:
        return None

def main():
    os.makedirs(RAW, exist_ok=True)
    rows = []

    for city, meta in CITIES.items():
        code = meta["wb_code"]
        print(f"\n  {city}  ({code})")
        for ind_code, col_name in WB_INDICATORS.items():
            api_data = try_api(code, ind_code)
            fb       = WB_FALLBACK.get(code, {}).get(col_name, [])

            for yi, year in enumerate(YEARS):
                if api_data and year in api_data and api_data[year] is not None:
                    val = float(api_data[year])
                    src = "API"
                elif yi < len(fb):
                    val = float(fb[yi])
                    src = "published"
                else:
                    val = np.nan
                    src = "missing"
                rows.append({"city": city, "wb_code": code, "year": year,
                             "indicator": col_name, "value": val, "source": src})

            sources = set(r["source"] for r in rows
                          if r["city"]==city and r["indicator"]==col_name)
            print(f"    {col_name:<32s}  [{', '.join(sources)}]")
        time.sleep(0.3)

    df = pd.DataFrame(rows)
    wide = df.pivot_table(index=["city","wb_code","year"],
                          columns="indicator", values="value",
                          aggfunc="mean").reset_index()
    wide.columns.name = None
    for col in WB_INDICATORS.values():
        if col in wide.columns:
            wide[col] = wide.groupby("city")[col].transform(
                lambda s: s.interpolate("linear").ffill().bfill())

    out = os.path.join(RAW, "worldbank_wdi.csv")
    wide.to_csv(out, index=False)

    print(f"\n{'='*52}")
    print(f"  Saved → {out}  {wide.shape}")
    print(f"\n  Data source summary (API = live World Bank; published = fallback):")
    src_summary = df.groupby(["city","source"]).size().unstack(fill_value=0)
    print(src_summary.to_string())

if __name__ == "__main__":
    main()
