#!/usr/bin/env bash
# GreenTwin-SDG  ·  Full Pipeline (real-data edition)
# Usage: source venv/bin/activate && bash run_pipeline.sh
set -e
START=$(date +%s)
log() { echo ""; echo "══════════════════════════════════════════════"; echo "  $1"; echo "══════════════════════════════════════════════"; }
ok()  { echo "  ✓  $1"; }

log "STEP 01 — World Bank WDI (API + published fallback)"
python 01_acquire_worldbank.py
ok "worldbank_wdi.csv written"

log "STEP 02 — UN SDG Targets (SDSN 2023 published values)"
python 02_acquire_sdg.py
ok "un_sdg_indicators.csv written"

log "STEP 03 — Real Air Quality (Open-Meteo CAMS, no API key)"
python 03_fetch_airquality.py
ok "openmeteo_combined.parquet written"

log "STEP 04 — Pre-processing and QC"
python 04_preprocess.py
ok "monthly_aq.csv + monthly_wb.csv written"

log "STEP 05 — Feature Engineering (HEI, OBI, COP, SAS, DCI)"
python 05_feature_engineering.py
ok "feature_matrix.csv written"

log "STEP 06 — XGBoost Model Training"
python 06_train_models.py
ok "Models + performance_metrics.csv written"

log "STEP 07 — SHAP Explainability"
python 07_shap_analysis.py
ok "shap_summary_table.csv written"

log "STEP 08 — Figures (Fig 2 + Fig 3 only)"
python regenerate_figs2_3.py
ok "Fig2_SHAP_Beeswarm.png + Fig3_SDG_Heatmap.png written"

END=$(date +%s)
echo ""
echo "══════════════════════════════════════════════"
echo "  ✓  Pipeline complete in $((END-START))s"
echo "══════════════════════════════════════════════"
echo ""
echo "  Data sources used:"
echo "    Air quality : Open-Meteo CAMS Reanalysis API (REAL, free, no key)"
echo "    World Bank  : api.worldbank.org (REAL, free) or published fallback"
echo "    SDG targets : SDSN 2023 Sustainable Development Report (published)"
echo ""
echo "  Key outputs:"
echo "    outputs/figures/Fig2_SHAP_Beeswarm.png"
echo "    outputs/figures/Fig3_SDG_Heatmap.png"
echo "    outputs/results/performance_metrics.csv"
echo "    outputs/results/shap_summary_table.csv"
