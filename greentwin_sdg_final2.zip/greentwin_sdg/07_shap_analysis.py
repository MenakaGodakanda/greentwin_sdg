"""
GreenTwin-SDG  ·  Step 07 — SHAP Explainability Analysis
==========================================================
Computes TreeSHAP values for all test-set predictions
across every SDG cluster and exports:
  • Per-prediction SHAP matrix (full attribution)
  • Global importance table (mean |SHAP| per feature)
  • Cluster-level top-feature summary (Table III in paper)

Inputs  : outputs/models/model_<cluster>.json
          outputs/models/meta_<cluster>.json
          outputs/results/test_preds_<cluster>.csv
Outputs : outputs/results/shap_values_<cluster>.csv
          outputs/results/shap_importance_<cluster>.csv
          outputs/results/shap_summary_table.csv   (Table III)
          outputs/results/shap_report.txt
"""

import os, json, warnings
import numpy as np
import pandas as pd
import shap
from xgboost import XGBRegressor
warnings.filterwarnings("ignore")

from config import SDG_CLUSTERS, MODELS, RESULTS

def main():
    os.makedirs(RESULTS, exist_ok=True)
    summary_rows = []
    report_lines = ["GreenTwin-SDG · SHAP Analysis Report", "=" * 55, ""]

    for cluster_name in SDG_CLUSTERS.keys():
        print(f"\n{'─'*55}")
        print(f"  Cluster : {cluster_name}")

        # ── Load model and metadata ────────────────────────────────────────
        model_path = os.path.join(MODELS, f"model_{cluster_name}.json")
        meta_path  = os.path.join(MODELS, f"meta_{cluster_name}.json")
        pred_path  = os.path.join(RESULTS, f"test_preds_{cluster_name}.csv")

        model = XGBRegressor()
        model.load_model(model_path)

        with open(meta_path) as f:
            meta = json.load(f)
        feature_cols = meta["feature_cols"]

        test_df = pd.read_csv(pred_path)
        X_test  = test_df[feature_cols].values
        print(f"    Test records : {len(X_test):,}")

        # ── Compute TreeSHAP ──────────────────────────────────────────────
        explainer   = shap.TreeExplainer(model)
        shap_values = explainer.shap_values(X_test)   # shape (n, p)

        # ── Per-prediction SHAP matrix ────────────────────────────────────
        shap_df = pd.DataFrame(shap_values, columns=feature_cols)
        shap_df.insert(0, "city", test_df["city"].values)
        pass  # year not in test_df
        pass
        shap_df.insert(3, "y_true", test_df[cluster_name].values)
        shap_df.insert(4, "y_pred", test_df["xgb_pred"].values)
        shap_path = os.path.join(RESULTS, f"shap_values_{cluster_name}.csv")
        shap_df.to_csv(shap_path, index=False)

        # ── Global importance (mean |SHAP|) ───────────────────────────────
        importance = pd.DataFrame({
            "feature":    feature_cols,
            "mean_abs_shap": np.abs(shap_values).mean(axis=0),
        }).sort_values("mean_abs_shap", ascending=False).reset_index(drop=True)

        imp_path = os.path.join(RESULTS, f"shap_importance_{cluster_name}.csv")
        importance.to_csv(imp_path, index=False)

        # ── Top-3 and cumulative variance ─────────────────────────────────
        total_var = importance["mean_abs_shap"].sum()
        top3 = importance.head(3)
        top3_var_pct = top3["mean_abs_shap"].sum() / total_var * 100

        print(f"    Top-3 features (mean |SHAP|):")
        for _, row in top3.iterrows():
            pct = row["mean_abs_shap"] / total_var * 100
            print(f"      {row['feature']:<35s}  |SHAP|={row['mean_abs_shap']:.3f}  ({pct:.1f}%)")
        print(f"    Top-3 cumulative variance : {top3_var_pct:.1f}%")

        summary_rows.append({
            "SDG Cluster": cluster_name,
            "Top Feature 1": top3.iloc[0]["feature"],
            "|SHAP| 1": round(top3.iloc[0]["mean_abs_shap"], 3),
            "Top Feature 2": top3.iloc[1]["feature"],
            "|SHAP| 2": round(top3.iloc[1]["mean_abs_shap"], 3),
            "Top Feature 3": top3.iloc[2]["feature"],
            "|SHAP| 3": round(top3.iloc[2]["mean_abs_shap"], 3),
            "Cumulative Variance (%)": round(top3_var_pct, 1),
        })

        # ── SHAP axiom verification ───────────────────────────────────────
        # local accuracy: SHAP sum ≈ model_output - baseline
        baseline_val = explainer.expected_value
        shap_sum = shap_values.sum(axis=1)
        pred_from_shap = shap_sum + baseline_val
        residual = np.abs(pred_from_shap - test_df["xgb_pred"].values).mean()
        print(f"    SHAP local accuracy residual (mean) : {residual:.5f}")

        report_lines += [
            f"Cluster: {cluster_name}",
            f"  Test records         : {len(X_test):,}",
            f"  SHAP baseline        : {baseline_val:.3f}",
            f"  Local accuracy error : {residual:.5f}",
            f"  Top-3 cumul. var.    : {top3_var_pct:.1f}%",
            f"  Top features:",
        ]
        for _, row in top3.iterrows():
            report_lines.append(
                f"    {row['feature']:<35s}  {row['mean_abs_shap']:.3f}")
        report_lines.append("")

    # ── Table III: cross-cluster summary ──────────────────────────────────────
    summary_df = pd.DataFrame(summary_rows)
    tbl_path = os.path.join(RESULTS, "shap_summary_table.csv")
    summary_df.to_csv(tbl_path, index=False)

    print(f"\n{'='*55}")
    print("  SHAP SUMMARY TABLE (Table III of paper)")
    print(f"{'='*55}")
    print(summary_df[["SDG Cluster","Top Feature 1","Top Feature 2",
                       "Top Feature 3","Cumulative Variance (%)"]].to_string(index=False))

    rpt_path = os.path.join(RESULTS, "shap_report.txt")
    with open(rpt_path, "w") as f:
        f.write("\n".join(report_lines))

    print(f"\n  SHAP values  → {RESULTS}/shap_values_<cluster>.csv")
    print(f"  Importance   → {RESULTS}/shap_importance_<cluster>.csv")
    print(f"  Summary tbl  → {tbl_path}")
    print(f"  Report       → {rpt_path}")

if __name__ == "__main__":
    main()
