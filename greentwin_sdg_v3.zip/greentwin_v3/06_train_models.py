"""
GreenTwin-SDG v3  ·  Step 06 — Model Training
===============================================
Trains one XGBoost regressor per SDG cluster using
country-stratified 70/15/15 splits and Bayesian search.
Ridge regression provides the linear baseline.

Input  : data/processed/feature_matrix.csv
Outputs: outputs/models/model_<cluster>.json
         outputs/models/meta_<cluster>.json
         outputs/results/test_preds_<cluster>.csv
         outputs/results/performance_metrics.csv
         outputs/results/training_report.txt
"""

import os, sys, json, warnings
import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from xgboost import XGBRegressor
warnings.filterwarnings("ignore")

from config import SDG_CLUSTERS, PROCESSED, MODELS, RESULTS, SEED

META_COLS = {"country", "year", "month", "wb_code", "timestamp"}

def get_feature_cols(df):
    targets = set(SDG_CLUSTERS.keys())
    excl    = META_COLS | targets
    return [c for c in df.columns if c not in excl
            and df[c].dtype in ("float64","int64","float32","int32")]

def stratified_split(df, seed=SEED):
    countries = np.array(sorted(df["country"].unique()))
    rng = np.random.default_rng(seed)
    rng.shuffle(countries)
    n   = len(countries)
    n_tr = max(1, int(n * 0.70))
    n_va = max(1, int(n * 0.15))
    tr = countries[:n_tr]
    va = countries[n_tr:n_tr+n_va]
    te = countries[n_tr+n_va:]
    if len(te) == 0:
        te = va[-1:]; va = va[:-1]
    return (df[df["country"].isin(tr)].copy(),
            df[df["country"].isin(va)].copy(),
            df[df["country"].isin(te)].copy())

def bayesian_search(X_tr, y_tr, X_va, y_va, n_iter=30, seed=SEED):
    rng = np.random.default_rng(seed)
    best_mae, best_p = np.inf, {}
    for _ in range(n_iter):
        p = {
            "learning_rate":    float(rng.uniform(0.01, 0.30)),
            "max_depth":        int(rng.integers(3, 9)),
            "subsample":        float(rng.uniform(0.60, 1.00)),
            "colsample_bytree": float(rng.uniform(0.60, 1.00)),
            "n_estimators":     200,
            "early_stopping_rounds": 20,
            "random_state":     seed,
            "verbosity":        0,
        }
        m = XGBRegressor(**p)
        m.fit(X_tr, y_tr, eval_set=[(X_va, y_va)], verbose=False)
        mae = mean_absolute_error(y_va, m.predict(X_va))
        if mae < best_mae:
            best_mae = mae
            best_p   = {k: v for k, v in p.items()
                       if k not in ("early_stopping_rounds","verbosity")}
    return best_p, best_mae

def metrics(y_true, y_pred, label):
    mae  = mean_absolute_error(y_true, y_pred)
    rmse = float(np.sqrt(mean_squared_error(y_true, y_pred)))
    r2   = r2_score(y_true, y_pred)
    print(f"    {label:<10s}  MAE={mae:.3f}  RMSE={rmse:.3f}  R²={r2:.3f}")
    return {"split": label, "mae": mae, "rmse": rmse, "r2": r2}

def main():
    os.makedirs(MODELS, exist_ok=True)
    os.makedirs(RESULTS, exist_ok=True)

    fm_path = os.path.join(PROCESSED, "feature_matrix.csv")
    if not os.path.exists(fm_path):
        print("  ERROR: feature_matrix.csv not found. Run step 05 first.")
        sys.exit(1)

    df = pd.read_csv(fm_path)
    feature_cols = get_feature_cols(df)
    print(f"  Feature matrix : {df.shape[0]:,} rows × {len(feature_cols)} features")
    print(f"  Countries      : {sorted(df['country'].unique())}")
    print(f"  Years          : {sorted(df['year'].unique())}")

    all_metrics  = []
    report_lines = ["GreenTwin-SDG v3 · Training Report", "="*60, ""]

    for ci, cluster_name in enumerate(SDG_CLUSTERS.keys()):
        print(f"\n{'─'*60}\n  Cluster : {cluster_name}")

        sub = df[feature_cols + ["country","year","month",cluster_name]].dropna(
            subset=[cluster_name])
        if len(sub) < 20:
            print(f"    SKIP — only {len(sub)} labelled rows")
            continue

        tr, va, te = stratified_split(sub, seed=SEED+ci)
        X_tr, y_tr = tr[feature_cols].values, tr[cluster_name].values
        X_va, y_va = va[feature_cols].values, va[cluster_name].values
        X_te, y_te = te[feature_cols].values, te[cluster_name].values

        print(f"    Train: {len(X_tr):>4,}  ({sorted(tr['country'].unique())})")
        print(f"    Val  : {len(X_va):>4,}  ({sorted(va['country'].unique())})")
        print(f"    Test : {len(X_te):>4,}  ({sorted(te['country'].unique())})")

        best_p, val_mae = bayesian_search(X_tr, y_tr, X_va, y_va, seed=SEED+ci)
        print(f"    Best val MAE = {val_mae:.3f}  |  "
              f"lr={best_p['learning_rate']:.3f}  depth={best_p['max_depth']}")

        X_tv = np.vstack([X_tr, X_va]); y_tv = np.concatenate([y_tr, y_va])
        final = XGBRegressor(**best_p, verbosity=0)
        final.fit(X_tv, y_tv)

        sc = StandardScaler()
        bl = Ridge()
        bl.fit(sc.fit_transform(X_tv), y_tv)
        bl_pred  = bl.predict(sc.transform(X_te))
        xgb_pred = final.predict(X_te)

        print(f"    Test-set performance:")
        m_xgb = metrics(y_te, xgb_pred, "XGBoost")
        m_bl  = metrics(y_te, bl_pred,  "Ridge")

        threshold_ok = m_xgb["mae"] < 6.0
        delta = (m_bl["mae"] - m_xgb["mae"]) / (m_bl["mae"]+1e-9) * 100
        print(f"    MAE < 6 threshold : {'PASS' if threshold_ok else 'FAIL'}")
        print(f"    MAE Δ vs Ridge    : {delta:+.1f}%")

        m_xgb.update({"cluster":cluster_name,"model":"XGBoost",
                      "delta_pct":round(delta,1),"threshold_pass":threshold_ok})
        m_bl.update({"cluster":cluster_name,"model":"Ridge",
                     "delta_pct":0.0,"threshold_pass":False})
        all_metrics.extend([m_xgb, m_bl])

        model_path = os.path.join(MODELS, f"model_{cluster_name}.json")
        meta_path  = os.path.join(MODELS, f"meta_{cluster_name}.json")
        final.save_model(model_path)
        with open(meta_path, "w") as f:
            json.dump({"feature_cols": feature_cols, "best_params": best_p,
                      "test_countries": sorted(te["country"].unique()),
                      "val_mae": val_mae, "threshold_pass": threshold_ok}, f, indent=2)

        te = te.copy()
        te["xgb_pred"]   = xgb_pred
        te["ridge_pred"] = bl_pred
        te.to_csv(os.path.join(RESULTS, f"test_preds_{cluster_name}.csv"), index=False)

        report_lines += [
            f"Cluster: {cluster_name}",
            f"  Train/Val/Test : {len(X_tr)}/{len(X_va)}/{len(X_te)}",
            f"  XGBoost MAE/RMSE/R² : {m_xgb['mae']:.3f} / {m_xgb['rmse']:.3f} / {m_xgb['r2']:.3f}",
            f"  Ridge   MAE/RMSE/R² : {m_bl['mae']:.3f} / {m_bl['rmse']:.3f} / {m_bl['r2']:.3f}",
            f"  MAE Δ vs Ridge : {delta:.1f}%",
            f"  Threshold (<6) : {'PASS' if threshold_ok else 'FAIL'}",
            "",
        ]

    if not all_metrics:
        print("\n  ERROR: No models trained.")
        sys.exit(1)

    metrics_df = pd.DataFrame(all_metrics)
    xgb_df = metrics_df[metrics_df["model"]=="XGBoost"][
        ["cluster","mae","rmse","r2","delta_pct","threshold_pass"]].round(3)

    print(f"\n{'='*60}\n  FINAL PERFORMANCE (XGBoost, test set)\n{'='*60}")
    print(xgb_df.to_string(index=False))

    metrics_df.to_csv(os.path.join(RESULTS, "performance_metrics.csv"), index=False)
    with open(os.path.join(RESULTS, "training_report.txt"), "w") as f:
        f.write("\n".join(report_lines))

    print(f"\n  Models  → {MODELS}/")
    print(f"  Metrics → {RESULTS}/performance_metrics.csv")

if __name__ == "__main__":
    main()
