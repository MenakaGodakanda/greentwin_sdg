"""
GreenTwin-SDG v3  ·  Step 05 — Feature Engineering
====================================================
Builds composite air quality features (HEI, OBI, COP, SAS),
rolling/lag features, merges World Bank socioeconomic data,
and merges SDSN 2024 cluster gap-score targets.

Note: any remaining NaN in WB features (genuine API gaps,
no fallback) is imputed using the median of the SAME
COUNTRY's other available years; if no real data exists at
all for that country-indicator, the column is dropped and
reported, never fabricated.

Input  : data/processed/monthly_aq.csv
         data/processed/monthly_wb.csv
         data/raw/sdsn_cluster_targets.csv
Output : data/processed/feature_matrix.csv
         data/processed/feature_summary.txt
"""

import os, sys, warnings
import numpy as np
import pandas as pd
warnings.filterwarnings("ignore")

from config import (SDG_CLUSTERS, PROCESSED, RAW,
                    WHO_PM25_GUIDELINE, WHO_NO2_GUIDELINE, SEED)

np.random.seed(SEED)

def build_hei(df):
    if "pm25" not in df.columns or "no2" not in df.columns:
        return pd.Series(np.nan, index=df.index, name="hei")
    n_pm25 = (df["pm25"] / WHO_PM25_GUIDELINE).clip(0, 50)
    n_no2  = (df["no2"]  / WHO_NO2_GUIDELINE ).clip(0, 50)
    return np.sqrt(n_pm25 * n_no2).rename("hei")

def build_obi(df):
    return (df["o3"] / 100.0).clip(0, 5).rename("obi") if "o3" in df.columns \
        else pd.Series(np.nan, index=df.index, name="obi")

def build_cop(df):
    return (df["co"] / 4000.0).clip(0, 10).rename("cop") if "co" in df.columns \
        else pd.Series(np.nan, index=df.index, name="cop")

def build_sas(df):
    df = df.copy()
    df["sas"] = np.nan
    if "log_pm25" not in df.columns:
        return df
    for country in df["country"].unique():
        mask = df["country"] == country
        s    = df.loc[mask, "log_pm25"]
        rm   = s.rolling(12, min_periods=4).mean().shift(1)
        rs   = s.rolling(12, min_periods=4).std().shift(1)
        z    = (s - rm) / rs.replace(0, np.nan)
        df.loc[mask, "sas"] = z.values
    df["sas"] = df["sas"].fillna(0.0)
    return df

def add_rolling_lag(df):
    targets = [f for f in ["log_pm25","log_no2","hei"] if f in df.columns]
    for feat in targets:
        for w in (3, 6):
            df[f"{feat}_roll{w}"] = (df.groupby("country")[feat]
                                      .transform(lambda s: s.rolling(w, min_periods=1).mean()))
        df[f"{feat}_lag1"] = df.groupby("country")[feat].shift(1).bfill()
    return df

def main():
    aq_path  = os.path.join(PROCESSED, "monthly_aq.csv")
    wb_path  = os.path.join(PROCESSED, "monthly_wb.csv")
    sdg_path = os.path.join(RAW, "sdsn_cluster_targets.csv")

    for p in (aq_path, wb_path, sdg_path):
        if not os.path.exists(p):
            print(f"  ERROR: {p} not found. Run earlier steps first.")
            sys.exit(1)

    aq  = pd.read_csv(aq_path)
    wb  = pd.read_csv(wb_path)
    sdg = pd.read_csv(sdg_path)

    print(f"  AQ rows  : {len(aq):,}")
    print(f"  WB rows  : {len(wb):,}")
    print(f"  SDG rows : {len(sdg):,}")

    # ── Composite features ──────────────────────────────────────────────────
    print("\n── Building composite features")
    aq["hei"] = build_hei(aq)
    aq["obi"] = build_obi(aq)
    aq["cop"] = build_cop(aq)
    aq        = build_sas(aq)
    aq        = add_rolling_lag(aq)
    print("  HEI, OBI, COP, SAS, rolling/lag features  ✓")

    # ── Merge World Bank ─────────────────────────────────────────────────────
    wb_drop = [c for c in ["wb_code"] if c in wb.columns]
    feat = aq.merge(wb.drop(columns=wb_drop, errors="ignore"),
                    on=["country","year","month"], how="left")
    print(f"\n  Feature matrix after WB merge: {feat.shape}")

    # ── Report and impute remaining genuine NaN in WB columns ───────────────
    wb_cols = [c for c in wb.columns if c not in ("country","wb_code","year","month")]
    print(f"\n── Checking remaining missing values (real API gaps, no fallback)")
    for col in wb_cols:
        n_missing = feat[col].isna().sum()
        if n_missing > 0:
            pct = n_missing / len(feat) * 100
            print(f"  {col:<32s}  {n_missing} missing ({pct:.1f}%)")
            # Impute using same-country median of REAL observed values only
            feat[col] = feat.groupby("country")[col].transform(
                lambda s: s.fillna(s.median()) if s.notna().any() else s)
            still_missing = feat[col].isna().sum()
            if still_missing > 0:
                print(f"    ⚠ {still_missing} rows still missing — "
                      f"country has ZERO real API values for this indicator")
                print(f"    Countries affected: "
                      f"{sorted(feat.loc[feat[col].isna(),'country'].unique())}")

    # ── Merge SDSN cluster targets ────────────────────────────────────────────
    sdg_wide = sdg.pivot_table(index=["country","year","month"],
                               columns="cluster", values="cluster_gap").reset_index()
    sdg_wide.columns.name = None
    feat = feat.merge(sdg_wide, on=["country","year","month"], how="left")

    cluster_cols = list(SDG_CLUSTERS.keys())
    before = len(feat)
    feat = feat.dropna(subset=cluster_cols, how="all").reset_index(drop=True)
    print(f"\n  Rows after target merge: {len(feat):,} (dropped {before-len(feat):,} with no labels)")

    # ── Identify final feature columns ────────────────────────────────────────
    meta_cols = {"country","wb_code","year","month","timestamp","day","hour"}
    excl      = meta_cols | set(cluster_cols)
    feature_cols = [c for c in feat.columns if c not in excl
                    and feat[c].dtype in ("float64","int64","float32","int32")]

    # ── Drop any feature column that is entirely NaN (no real data anywhere) ─
    all_nan_cols = [c for c in feature_cols if feat[c].isna().all()]
    if all_nan_cols:
        print(f"\n  ⚠ Dropping columns with NO real data in any country: {all_nan_cols}")
        feat = feat.drop(columns=all_nan_cols)
        feature_cols = [c for c in feature_cols if c not in all_nan_cols]

    # ── Save ───────────────────────────────────────────────────────────────────
    out_path = os.path.join(PROCESSED, "feature_matrix.csv")
    feat.to_csv(out_path, index=False)

    # ── Summary ────────────────────────────────────────────────────────────────
    lines = ["GreenTwin-SDG v3 · Feature Summary", "="*55, "",
             f"Rows     : {len(feat):,}",
             f"Features : {len(feature_cols)}",
             f"Countries: {sorted(feat['country'].unique())}",
             f"Years    : {sorted(feat['year'].unique())}",
             "", f"{'Feature':<38s}  {'Mean':>8}  {'Std':>8}  {'Missing%':>8}"]
    lines.append("-"*68)
    for c in feature_cols:
        miss = feat[c].isna().mean()*100
        lines.append(f"  {c:<36s}  {feat[c].mean():8.3f}  "
                     f"{feat[c].std():8.3f}  {miss:7.1f}%")
    lines += ["", "SDG Cluster target statistics (gap score, 0=on-track, 100=worst):"]
    for cl in cluster_cols:
        if cl in feat.columns:
            lines.append(f"  {cl:<30s}  mean={feat[cl].mean():.1f}  "
                         f"std={feat[cl].std():.1f}  "
                         f"min={feat[cl].min():.1f}  max={feat[cl].max():.1f}")

    rpt_path = os.path.join(PROCESSED, "feature_summary.txt")
    with open(rpt_path, "w") as f:
        f.write("\n".join(lines))

    print(f"\n{'='*55}")
    print(f"  feature_matrix.csv  →  {feat.shape[0]:,} rows × {feat.shape[1]} cols")
    print(f"  Feature columns used in model: {len(feature_cols)}")
    print(f"\n  Target cluster statistics:")
    for cl in cluster_cols:
        if cl in feat.columns:
            print(f"    {cl:<30s}  mean={feat[cl].mean():.1f}  "
                  f"std={feat[cl].std():.1f}  "
                  f"min={feat[cl].min():.1f}  max={feat[cl].max():.1f}")
    print(f"\n  Feature summary → {rpt_path}")

if __name__ == "__main__":
    main()
